"""Завдання 2. Симетричне дерево. Час O(n), пам'ять O(n)."""
from common import TreeNode


def isSymmetric(root: TreeNode | None) -> bool:
    if root is None:
        return True
    stack = [(root.left, root.right)]
    while stack:
        left, right = stack.pop()
        if left is None or right is None:
            if left is not right:
                return False
            continue
        if left.val != right.val:
            return False
        stack.append((left.left, right.right))
        stack.append((left.right, right.left))
    return True
