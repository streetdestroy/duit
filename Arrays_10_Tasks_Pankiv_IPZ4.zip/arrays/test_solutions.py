"""Тести всіх десяти задач. Запуск: python -m unittest -v test_solutions.py"""
import random
import unittest

from task01_max_ones import find_max_consecutive_ones
from task02_even_digits import find_numbers
from task03_sorted_squares import sorted_squares
from task04_duplicate_zeros import duplicate_zeros
from task05_merge_sorted import merge
from task06_remove_duplicates import remove_duplicates
from task07_double_exists import check_if_exist
from task08_mountain import valid_mountain_array
from task09_replace_right_max import replace_elements
from task10_sort_parity import sort_array_by_parity


class ArraysTests(unittest.TestCase):
    def test_01_examples_and_edge(self):
        self.assertEqual(find_max_consecutive_ones([1, 1, 0, 1, 1, 1]), 3)
        self.assertEqual(find_max_consecutive_ones([1, 0, 1, 1, 0, 1]), 2)
        self.assertEqual(find_max_consecutive_ones([0] * 100_000), 0)
        self.assertEqual(find_max_consecutive_ones([1] * 100_000), 100_000)

    def test_02_examples_and_edge(self):
        self.assertEqual(find_numbers([12, 345, 2, 6, 7896]), 2)
        self.assertEqual(find_numbers([555, 901, 482, 1771]), 1)
        self.assertEqual(find_numbers([1, 100000, 9999, 999]), 2)

    def test_03_examples_and_random(self):
        self.assertEqual(sorted_squares([-4, -1, 0, 3, 10]), [0, 1, 9, 16, 100])
        self.assertEqual(sorted_squares([-7, -3, 2, 3, 11]), [4, 9, 9, 49, 121])
        rng = random.Random(17)
        for _ in range(100):
            a = sorted(rng.randint(-10000, 10000) for _ in range(60))
            self.assertEqual(sorted_squares(a), sorted(x * x for x in a))

    def test_04_examples_and_random(self):
        a = [1, 0, 2, 3, 0, 4, 5, 0]
        self.assertIsNone(duplicate_zeros(a))
        self.assertEqual(a, [1, 0, 0, 2, 3, 0, 0, 4])
        a = [1, 2, 3]
        duplicate_zeros(a)
        self.assertEqual(a, [1, 2, 3])
        rng = random.Random(18)
        for _ in range(150):
            a = [rng.randint(0, 5) for _ in range(rng.randint(1, 100))]
            expect = []
            for x in a:
                expect.append(x)
                if x == 0:
                    expect.append(0)
            expect = expect[:len(a)]
            duplicate_zeros(a)
            self.assertEqual(a, expect)

    def test_05_examples_and_random(self):
        a = [1, 2, 3, 0, 0, 0]
        self.assertIsNone(merge(a, 3, [2, 5, 6], 3))
        self.assertEqual(a, [1, 2, 2, 3, 5, 6])
        a = [1]
        merge(a, 1, [], 0)
        self.assertEqual(a, [1])
        a = [0]
        merge(a, 0, [1], 1)
        self.assertEqual(a, [1])
        rng = random.Random(19)
        for _ in range(100):
            m = rng.randint(0, 50)
            n = rng.randint(0, 50)
            if not m + n:
                n = 1
            a = sorted(rng.randint(-10, 10) for _ in range(m))
            b = sorted(rng.randint(-10, 10) for _ in range(n))
            c = a + [0] * n
            merge(c, m, b, n)
            self.assertEqual(c, sorted(a + b))

    def test_06_examples_and_random(self):
        a = [1, 1, 2]
        k = remove_duplicates(a)
        self.assertEqual((k, a[:k]), (2, [1, 2]))
        a = [0, 0, 1, 1, 1, 2, 2, 3, 3, 4]
        k = remove_duplicates(a)
        self.assertEqual((k, a[:k]), (5, [0, 1, 2, 3, 4]))
        rng = random.Random(20)
        for _ in range(100):
            a = sorted(rng.randint(-100, 100) for _ in range(150))
            expected = sorted(set(a))
            k = remove_duplicates(a)
            self.assertEqual((k, a[:k]), (len(expected), expected))

    def test_07_examples_and_zero(self):
        self.assertTrue(check_if_exist([10, 2, 5, 3]))
        self.assertFalse(check_if_exist([3, 1, 7, 11]))
        self.assertTrue(check_if_exist([0, 0]))
        self.assertFalse(check_if_exist([0, 1]))
        self.assertTrue(check_if_exist([-2, -4]))
        self.assertFalse(check_if_exist([1, 3]))

    def test_08_examples_and_plateaus(self):
        self.assertFalse(valid_mountain_array([2, 1]))
        self.assertFalse(valid_mountain_array([3, 5, 5]))
        self.assertTrue(valid_mountain_array([0, 3, 2, 1]))
        self.assertTrue(valid_mountain_array([0, 1, 2, 3, 4, 2, 1]))
        self.assertFalse(valid_mountain_array([0, 2, 3, 3, 5, 2, 1]))
        self.assertFalse(valid_mountain_array([0, 1, 2]))
        self.assertFalse(valid_mountain_array([3, 2, 1]))

    def test_09_examples_and_random(self):
        self.assertEqual(replace_elements([17, 18, 5, 4, 6, 1]), [18, 6, 6, 6, 1, -1])
        self.assertEqual(replace_elements([400]), [-1])
        rng = random.Random(21)
        for _ in range(100):
            a = [rng.randint(1, 100000) for _ in range(rng.randint(1, 100))]
            exp = [max(a[i + 1:]) if i + 1 < len(a) else -1 for i in range(len(a))]
            self.assertEqual(replace_elements(a), exp)

    def test_10_examples_and_random(self):
        result = sort_array_by_parity([3, 1, 2, 4])
        self.assertEqual(sorted(result), [1, 2, 3, 4])
        self.assertEqual(sort_array_by_parity([0]), [0])
        rng = random.Random(22)
        for _ in range(100):
            a = [rng.randint(0, 5000) for _ in range(rng.randint(1, 100))]
            b = sort_array_by_parity(a[:])
            self.assertEqual(sorted(a), sorted(b))
            seen_odd = False
            for x in b:
                if x % 2:
                    seen_odd = True
                elif seen_odd:
                    self.fail("Парний елемент після непарного")


if __name__ == "__main__":
    unittest.main()
