"""Завдання 4. K-й найменший у BST. Час O(h+k), пам'ять O(h)."""
from common import TreeNode


def kthSmallest(root: TreeNode | None, k: int) -> int:
    """Ітеративний симетричний обхід BST: ліве піддерево -> вузол -> праве."""
    stack = []
    node = root
    while stack or node is not None:
        while node is not None:
            stack.append(node)
            node = node.left
        node = stack.pop()
        k -= 1
        if k == 0:
            return node.val
        node = node.right
    raise ValueError('k має бути в діапазоні від 1 до кількості вузлів')
