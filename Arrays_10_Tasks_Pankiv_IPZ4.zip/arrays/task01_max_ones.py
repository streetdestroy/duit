"""Завдання 1. Максимальна кількість послідовних одиниць."""


def find_max_consecutive_ones(nums: list[int]) -> int:
    current = 0
    maximum = 0
    for value in nums:
        if value == 1:
            current += 1
            if current > maximum:
                maximum = current
        else:
            current = 0
    return maximum


if __name__ == "__main__":
    print(find_max_consecutive_ones([1, 1, 0, 1, 1, 1]))  # 3
    print(find_max_consecutive_ones([1, 0, 1, 1, 0, 1]))  # 2
