"""П'ять рекурсивних розв'язків. Цикли та сторонні бібліотеки не використовуються."""


# 1. Друк рядка у зворотному порядку
# Часова складність: O(n), додаткова пам'ять: O(n) для стека викликів.
def print_reverse(text: str) -> None:
    """Рекурсивно виводить символи рядка у зворотному порядку."""
    def show(index: int) -> None:
        if index == len(text):
            return
        show(index + 1)
        print(text[index], end="")

    show(0)
    print()


# Допоміжна функція для перевірки рядка без перехоплення stdout.
def reverse_string(text: str, index: int = 0) -> str:
    if index == len(text):
        return ""
    return reverse_string(text, index + 1) + text[index]


# 2. Обмін місцями сусідніх вузлів зв'язаного списку
# Час: O(n), стек викликів: O(n). Значення вузлів не змінюються.
class ListNode:
    def __init__(self, val: int = 0, next_node=None):
        self.val = val
        self.next = next_node


def swap_pairs(head):
    """Міняє місцями самі вузли попарно та повертає нову голову списку."""
    if head is None or head.next is None:
        return head

    second = head.next
    head.next = swap_pairs(second.next)
    second.next = head
    return second


def build_list(values, index: int = 0):
    """Створює зв'язаний список з Python-списку рекурсивно."""
    if index == len(values):
        return None
    return ListNode(values[index], build_list(values, index + 1))


def list_values(head):
    """Повертає значення зв'язаного списку як Python-список рекурсивно."""
    if head is None:
        return []
    return [head.val] + list_values(head.next)


# 3. n-те число Фібоначчі
# Хвостова рекурсія: O(n) часу, O(n) стека викликів.
def fibonacci(n: int) -> int:
    if n < 0:
        raise ValueError("n має бути невід'ємним цілим числом")

    def calculate(remaining: int, previous: int, current: int) -> int:
        if remaining == 0:
            return previous
        return calculate(remaining - 1, current, previous + current)

    return calculate(n, 0, 1)


# 4. Кількість способів піднятися сходами за 1 або 2 кроки
# Хвостова рекурсія: O(n) часу, O(n) стека викликів.
def climb_stairs(n: int) -> int:
    if not 1 <= n <= 45:
        raise ValueError("Кількість сходинок має бути у межах від 1 до 45")

    def calculate(remaining: int, previous: int, current: int) -> int:
        if remaining == 0:
            return previous
        return calculate(remaining - 1, current, previous + current)

    return calculate(n, 1, 1)


# 5. Піднесення числа до цілого степеня
# Рекурсивне швидке піднесення до степеня: O(log |n|).
def my_pow(x: float, n: int) -> float:
    if x == 0 and n <= 0:
        raise ValueError("Нуль не можна підносити до нульового чи від'ємного степеня")

    def positive_power(base: float, exponent: int) -> float:
        if exponent == 0:
            return 1.0
        half = positive_power(base, exponent // 2)
        square = half * half
        if exponent % 2 == 0:
            return square
        return square * base

    if n < 0:
        return positive_power(1.0 / x, -n)
    return positive_power(float(x), n)
