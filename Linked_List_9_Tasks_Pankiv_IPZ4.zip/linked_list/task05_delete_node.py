"""№5. Видалити вузол, маючи лише посилання на нього (не хвостовий)."""
from common import ListNode


def delete_node(node: ListNode) -> None:
    """Копіює наступне значення і прибирає наступний вузол зі списку.

    Важливо: саме тут за умовою дозволено змінювати значення вузла.
    """
    if node is None or node.next is None:
        raise ValueError("Потрібен вузол, який не є останнім")
    node.val = node.next.val
    node.next = node.next.next
