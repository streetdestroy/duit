"""Збірник 8 розв'язків «Черга (Queue)», Python 3.10+.

Студент: Паньків Даніїл Васильович, ІПЗ-4.
Завдання 1-8 ідуть за порядком у Google-формі (у формі номер 3 повторено).
"""
from collections import deque

# --- task01_first_unique.py ---
"""Завдання 1: перший неповторюваний символ у рядку."""

def firstUniqChar(s: str) -> int:
    frequencies = [0] * 26
    for ch in s:
        frequencies[ord(ch) - ord('a')] += 1
    for index, ch in enumerate(s):
        if frequencies[ord(ch) - ord('a')] == 1:
            return index
    return -1

# --- task02_stack_using_queues.py ---
"""Завдання 2: стек LIFO на основі двох черг FIFO."""


class MyStack:
    def __init__(self):
        self._main = deque()
        self._buffer = deque()

    def push(self, x: int) -> None:
        self._buffer.append(x)
        while self._main:
            self._buffer.append(self._main.popleft())
        self._main, self._buffer = self._buffer, self._main

    def pop(self) -> int:
        return self._main.popleft()

    def top(self) -> int:
        return self._main[0]

    def empty(self) -> bool:
        return not self._main

# --- task03_recent_counter.py ---
"""Завдання 3: кількість запитів за останні 3000 мс включно."""


class RecentCounter:
    def __init__(self):
        self._timestamps = deque()

    def ping(self, t: int) -> int:
        self._timestamps.append(t)
        while self._timestamps and self._timestamps[0] < t - 3000:
            self._timestamps.popleft()
        return len(self._timestamps)

# --- task04_circular_deque.py ---
"""Завдання 4 (повторний №3 у формі): кільцева двостороння черга.

Операції O(1). Тільки власний кільцевий буфер на масиві.
"""

class MyCircularDeque:
    def __init__(self, k: int):
        if k < 1:
            raise ValueError('k must be positive')
        self._data = [0] * k
        self._capacity = k
        self._head = 0
        self._size = 0

    def insertFront(self, value: int) -> bool:
        if self.isFull():
            return False
        self._head = (self._head - 1) % self._capacity
        self._data[self._head] = value
        self._size += 1
        return True

    def insertLast(self, value: int) -> bool:
        if self.isFull():
            return False
        tail = (self._head + self._size) % self._capacity
        self._data[tail] = value
        self._size += 1
        return True

    def deleteFront(self) -> bool:
        if self.isEmpty():
            return False
        self._head = (self._head + 1) % self._capacity
        self._size -= 1
        return True

    def deleteLast(self) -> bool:
        if self.isEmpty():
            return False
        self._size -= 1
        return True

    def getFront(self) -> int:
        return -1 if self.isEmpty() else self._data[self._head]

    def getRear(self) -> int:
        return -1 if self.isEmpty() else self._data[(self._head + self._size - 1) % self._capacity]

    def isEmpty(self) -> bool:
        return self._size == 0

    def isFull(self) -> bool:
        return self._size == self._capacity

# --- task05_circular_queue.py ---
"""Завдання 5 (№4 у формі): циклічна черга FIFO без готової черги."""

class MyCircularQueue:
    def __init__(self, k: int):
        if k < 1:
            raise ValueError('k must be positive')
        self._data = [0] * k
        self._capacity = k
        self._head = 0
        self._size = 0

    def enQueue(self, value: int) -> bool:
        if self.isFull():
            return False
        index = (self._head + self._size) % self._capacity
        self._data[index] = value
        self._size += 1
        return True

    def deQueue(self) -> bool:
        if self.isEmpty():
            return False
        self._head = (self._head + 1) % self._capacity
        self._size -= 1
        return True

    def Front(self) -> int:
        return -1 if self.isEmpty() else self._data[self._head]

    def Rear(self) -> int:
        return -1 if self.isEmpty() else self._data[(self._head + self._size - 1) % self._capacity]

    def isEmpty(self) -> bool:
        return self._size == 0

    def isFull(self) -> bool:
        return self._size == self._capacity

# --- task06_stamping_sequence.py ---
"""Завдання 6 (№5 у формі): штампування послідовності.

Розв'язок у зворотному напрямку: стираємо допустимі фрагменти,
після чого розвертаємо порядок ходів. Складність O(m*n).
"""


def movesToStamp(stamp: str, target: str) -> list[int]:
    m, n = len(stamp), len(target)
    if m > n:
        return []
    # dependents[p]: усі вікна, де символ у позиції p спочатку не збігається
    # із символом штампа. Коли p «стерто», відповідна невідповідність зникає.
    dependents = [[] for _ in range(n)]
    unresolved = [0] * (n - m + 1)
    for start in range(n - m + 1):
        for j, expected in enumerate(stamp):
            if target[start + j] != expected:
                unresolved[start] += 1
                dependents[start + j].append(start)

    ready = deque(i for i, count in enumerate(unresolved) if count == 0)
    erased = [False] * n
    result_reverse = []
    while ready:
        start = ready.popleft()
        result_reverse.append(start)
        for p in range(start, start + m):
            if erased[p]:
                continue
            erased[p] = True
            for affected in dependents[p]:
                unresolved[affected] -= 1
                if unresolved[affected] == 0:
                    ready.append(affected)

    if not all(erased) or len(result_reverse) > 10 * n:
        return []
    result_reverse.reverse()
    return result_reverse

# --- task07_sliding_window_max.py ---
"""Завдання 7 (№6 у формі): максимум кожного ковзного вікна, O(n)."""


def maxSlidingWindow(nums: list[int], k: int) -> list[int]:
    candidates = deque()  # індекси; значення у спадному порядку
    result = []
    for i, value in enumerate(nums):
        while candidates and candidates[0] <= i - k:
            candidates.popleft()
        while candidates and nums[candidates[-1]] <= value:
            candidates.pop()
        candidates.append(i)
        if i + 1 >= k:
            result.append(nums[candidates[0]])
    return result

# --- task08_constrained_subsequence_sum.py ---
"""Завдання 8 (№7 у формі): максимальна сума підпослідовності, O(n).

DP[i] = nums[i] + max(0, DP[j]) для i-k <= j < i.
Монотонна черга зберігає індекси кандидатів.
"""


def constrainedSubsetSum(nums: list[int], k: int) -> int:
    best_ending_here = [0] * len(nums)
    candidates = deque()
    best_result = nums[0]

    for i, value in enumerate(nums):
        while candidates and candidates[0] < i - k:
            candidates.popleft()
        previous_best = max(0, best_ending_here[candidates[0]]) if candidates else 0
        best_ending_here[i] = value + previous_best
        best_result = max(best_result, best_ending_here[i])
        while candidates and best_ending_here[candidates[-1]] <= best_ending_here[i]:
            candidates.pop()
        candidates.append(i)
    return best_result
