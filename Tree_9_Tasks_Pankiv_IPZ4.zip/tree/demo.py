"""Приклади з Google Forms. Запуск: python demo.py"""
from common import build_tree, tree_to_list
from task_01_same_tree import isSameTree
from task_02_symmetric_tree import isSymmetric
from task_03_invert_tree import invertTree
from task_04_kth_smallest import kthSmallest
from task_05_codec import Codec
from task_06_max_path_sum import maxPathSum
from task_07_cameras import minCameraCover
from task_08_vertical_traversal import verticalTraversal
from task_09_recover_preorder import recoverFromPreorder

print('1. Те саме дерево:', isSameTree(build_tree([1, 2, 3]), build_tree([1, 2, 3])))
print('2. Симетричне дерево:', isSymmetric(build_tree([1, 2, 2, 3, 4, 4, 3])))
print('3. Інверсія:', tree_to_list(invertTree(build_tree([4, 2, 7, 1, 3, 6, 9]))))
print('4. K-й елемент BST:', kthSmallest(build_tree([5, 3, 6, 2, 4, None, None, 1]), 3))
root = build_tree([1, 2, 3, None, None, 4, 5])
codec = Codec()
data = codec.serialize(root)
print('5. Серіалізація:', data, '->', tree_to_list(codec.deserialize(data)))
print('6. Максимальна сума шляху:', maxPathSum(build_tree([-10, 9, 20, None, None, 15, 7])))
print('7. Камери:', minCameraCover(build_tree([0, 0, None, 0, 0])))
print('8. Вертикальний обхід:', verticalTraversal(build_tree([1, 2, 3, 4, 5, 6, 7])))
print('9. Відновлення preorder:', tree_to_list(recoverFromPreorder('1-2--3--4-5--6--7')))
