"""Приклади з Google Forms для всіх семи задач."""
from all_solutions import (TreeNode, MinStack, MyQueue, is_valid, inorder_traversal,
                           decode_string, eval_rpn, longest_valid_parentheses)

print('№1:', is_valid('()'), is_valid('()[]{}'), is_valid('(]'))
# Рівень 0: 1; правий нащадок: 2; лівий нащадок вузла 2: 3.
root = TreeNode(1, None, TreeNode(2, TreeNode(3)))
print('№2:', inorder_traversal(root))

stack = MinStack()
stack.push(-2)
stack.push(0)
stack.push(-3)
print('№3 getMin:', stack.getMin())
stack.pop()
print('№3 top, getMin:', stack.top(), stack.getMin())

queue = MyQueue()
queue.push(1)
queue.push(2)
print('№4 peek, pop, empty:', queue.peek(), queue.pop(), queue.empty())
print('№5:', decode_string('3[a]2[bc]'), decode_string('3[a2[c]]'),
      decode_string('2[abc]3[cd]ef'))
print('№6:', eval_rpn(['2','1','+','3','*']),
      eval_rpn(['4','13','5','/','+']),
      eval_rpn(['10','6','9','3','+','-11','*','/','*','17','+','5','+']))
print('№7:', longest_valid_parentheses('(()'),
      longest_valid_parentheses(')()())'), longest_valid_parentheses(''))
