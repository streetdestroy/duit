"""Завдання 8 (№7 у формі): максимальна сума підпослідовності, O(n).

DP[i] = nums[i] + max(0, DP[j]) для i-k <= j < i.
Монотонна черга зберігає індекси кандидатів.
"""
from collections import deque


def constrainedSubsetSum(nums: list[int], k: int) -> int:
    best_ending_here = [0] * len(nums)
    candidates = deque()
    best_result = nums[0]

    for i, value in enumerate(nums):
        while candidates and candidates[0] < i - k:
            candidates.popleft()
        previous_best = max(0, best_ending_here[candidates[0]]) if candidates else 0
        best_ending_here[i] = value + previous_best
        best_result = max(best_result, best_ending_here[i])
        while candidates and best_ending_here[candidates[-1]] <= best_ending_here[i]:
            candidates.pop()
        candidates.append(i)
    return best_result


class Solution:
    def constrainedSubsetSum(self, nums: list[int], k: int) -> int:
        return constrainedSubsetSum(nums, k)
