"""Усі дев'ять задач про однозв'язні списки в одному незалежному файлі.
Автор: Паньків Даніїл Васильович, група ІПЗ-4.
"""


from __future__ import annotations


class ListNode:
    def __init__(self, val: int = 0, next: ListNode | None = None):
        self.val = val
        self.next = next

    def __repr__(self) -> str:
        return f"ListNode({self.val})"


def from_list(values):
    """Створити однозв'язний список із послідовності чисел."""
    dummy = ListNode()
    tail = dummy
    for value in values:
        tail.next = ListNode(value)
        tail = tail.next
    return dummy.next


def to_list(head, max_nodes: int = 20000) -> list[int]:
    """Зібрати значення вузлів; захистити приклад від циклічного списку."""
    result = []
    seen = set()
    current = head
    while current is not None:
        if id(current) in seen:
            raise ValueError("Список містить цикл")
        if len(result) >= max_nodes:
            raise ValueError("Список перевищує допустиму довжину для виведення")
        seen.add(id(current))
        result.append(current.val)
        current = current.next
    return result



# 1. task01_merge_two_sorted_lists.py
"""№1. Об'єднання двох відсортованих списків без створення нових вузлів даних."""


def merge_two_lists(list1: ListNode | None, list2: ListNode | None) -> ListNode | None:
    dummy = ListNode()
    tail = dummy
    while list1 is not None and list2 is not None:
        if list1.val <= list2.val:
            tail.next = list1
            list1 = list1.next
        else:
            tail.next = list2
            list2 = list2.next
        tail = tail.next
    tail.next = list1 if list1 is not None else list2
    return dummy.next



# 2. task02_remove_duplicates.py
"""№2. Видалення повторних вузлів із відсортованого списку."""


def delete_duplicates(head: ListNode | None) -> ListNode | None:
    current = head
    while current is not None and current.next is not None:
        if current.val == current.next.val:
            current.next = current.next.next
        else:
            current = current.next
    return head



# 3. task03_linked_list_cycle.py
"""№3. Перевірка на цикл алгоритмом Флойда (два покажчики)."""


def has_cycle(head: ListNode | None) -> bool:
    slow = fast = head
    while fast is not None and fast.next is not None:
        slow = slow.next
        fast = fast.next.next
        if slow is fast:
            return True
    return False



# 4. task04_reorder_list.py
"""№4. Перевпорядкування L0, Ln, L1, Ln-1 ... зміною next-посилань."""


def reorder_list(head: ListNode | None) -> None:
    """Змінює список на місці, нічого не повертає (як у LeetCode)."""
    if head is None or head.next is None:
        return

    # 1. Знайти кінець першої половини.
    slow = fast = head
    while fast.next is not None and fast.next.next is not None:
        slow = slow.next
        fast = fast.next.next

    # 2. Розвернути другу половину.
    second = slow.next
    slow.next = None
    previous = None
    while second is not None:
        following = second.next
        second.next = previous
        previous = second
        second = following

    # 3. Почергово приєднати вузли обох половин.
    first, second = head, previous
    while second is not None:
        first_next, second_next = first.next, second.next
        first.next = second
        second.next = first_next
        first, second = first_next, second_next



# 5. task05_delete_node.py
"""№5. Видалити вузол, маючи лише посилання на нього (не хвостовий)."""


def delete_node(node: ListNode) -> None:
    """Копіює наступне значення і прибирає наступний вузол зі списку.

    Важливо: саме тут за умовою дозволено змінювати значення вузла.
    """
    if node is None or node.next is None:
        raise ValueError("Потрібен вузол, який не є останнім")
    node.val = node.next.val
    node.next = node.next.next



# 6. task06_double_number.py
"""№6. Подвоїти число у вигляді списку цифр без перетворення у int."""


def _reverse(head: ListNode | None) -> ListNode | None:
    previous = None
    current = head
    while current is not None:
        following = current.next
        current.next = previous
        previous = current
        current = following
    return previous


def double_it(head: ListNode) -> ListNode:
    # Рух із молодших розрядів дозволяє переносити десятки.
    current = _reverse(head)
    reversed_head = current
    carry = 0
    tail = None
    while current is not None:
        value = current.val * 2 + carry
        current.val = value % 10
        carry = value // 10
        tail = current
        current = current.next
    if carry:
        tail.next = ListNode(carry)
    return _reverse(reversed_head)



# 7. task07_merge_k_sorted_lists.py
"""№7. Злиття k відсортованих списків попарно, O(N log k)."""


def merge_k_lists(lists: list[ListNode | None]) -> ListNode | None:
    if not lists:
        return None
    # Копія лише масиву посилань; вузли залишаються тими самими.
    heads = list(lists)
    interval = 1
    while interval < len(heads):
        for index in range(0, len(heads) - interval, interval * 2):
            heads[index] = merge_two_lists(heads[index], heads[index + interval])
        interval *= 2
    return heads[0]



# 8. task08_reverse_nodes_k_group.py
"""№8. Розвернути вузли по k, не торкаючись значень вузлів."""


def reverse_k_group(head: ListNode | None, k: int) -> ListNode | None:
    if k <= 1 or head is None:
        return head
    dummy = ListNode(0, head)
    before_group = dummy
    while True:
        # Перевірити, чи вистачає k вузлів для чергової групи.
        kth = before_group
        for _ in range(k):
            kth = kth.next
            if kth is None:
                return dummy.next

        after_group = kth.next
        previous = after_group
        current = before_group.next
        while current is not after_group:
            following = current.next
            current.next = previous
            previous = current
            current = following

        # Початок старої групи став її останнім вузлом.
        old_start = before_group.next
        before_group.next = kth
        before_group = old_start



# 9. task09_partition_list.py
"""№9. Стабільний поділ списку на значення < x та >= x."""


def partition_list(head: ListNode | None, x: int) -> ListNode | None:
    less_dummy = ListNode()
    greater_dummy = ListNode()
    less_tail = less_dummy
    greater_tail = greater_dummy
    current = head
    while current is not None:
        following = current.next
        current.next = None  # Від'єднуємо вузол від старого ланцюга.
        if current.val < x:
            less_tail.next = current
            less_tail = current
        else:
            greater_tail.next = current
            greater_tail = current
        current = following
    less_tail.next = greater_dummy.next
    return less_dummy.next
