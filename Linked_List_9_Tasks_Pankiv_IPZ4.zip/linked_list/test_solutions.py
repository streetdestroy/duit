"""Автоматичні тести для дев'яти задач про однозв'язні списки."""
from __future__ import annotations

import random
import unittest

from common import from_list, to_list
from task01_merge_two_sorted_lists import merge_two_lists
from task02_remove_duplicates import delete_duplicates
from task03_linked_list_cycle import has_cycle
from task04_reorder_list import reorder_list
from task05_delete_node import delete_node
from task06_double_number import double_it
from task07_merge_k_sorted_lists import merge_k_lists
from task08_reverse_nodes_k_group import reverse_k_group
from task09_partition_list import partition_list


def collect_nodes(head):
    """Ідентичності та значення вузлів для перевірки відсутності підміни."""
    seen = set()
    nodes = []
    while head is not None:
        if id(head) in seen:
            raise AssertionError('Виявлено несподіваний цикл')
        seen.add(id(head))
        nodes.append(head)
        head = head.next
    return nodes


def node_values_by_id(nodes):
    return {id(node): node.val for node in nodes}


class LinkedListTests(unittest.TestCase):
    def setUp(self):
        self.rng = random.Random(17)

    def test_01_examples(self):
        examples = [([1, 2, 4], [1, 3, 4], [1, 1, 2, 3, 4, 4]),
                    ([], [], []), ([], [0], [0])]
        for a, b, expected in examples:
            self.assertEqual(to_list(merge_two_lists(from_list(a), from_list(b))), expected)

    def test_01_random_nodes_are_reused(self):
        for _ in range(150):
            a = sorted(self.rng.choices(range(-100, 101), k=self.rng.randrange(51)))
            b = sorted(self.rng.choices(range(-100, 101), k=self.rng.randrange(51)))
            first, second = from_list(a), from_list(b)
            before = collect_nodes(first) + collect_nodes(second)
            result = merge_two_lists(first, second)
            self.assertEqual(to_list(result), sorted(a + b))
            self.assertEqual({id(n) for n in before}, {id(n) for n in collect_nodes(result)})

    def test_02_examples_and_empty(self):
        for source, expected in [([1, 1, 2], [1, 2]), ([1, 1, 2, 3, 3], [1, 2, 3]), ([], [])]:
            self.assertEqual(to_list(delete_duplicates(from_list(source))), expected)

    def test_02_random(self):
        for _ in range(100):
            source = sorted(self.rng.choices(range(-100, 101), k=self.rng.randrange(301)))
            self.assertEqual(to_list(delete_duplicates(from_list(source))), sorted(set(source)))

    def test_03_cycle_examples(self):
        head = from_list([3, 2, 0, -4])
        nodes = collect_nodes(head)
        nodes[-1].next = nodes[1]
        self.assertTrue(has_cycle(head))
        head2 = from_list([1, 2])
        nodes2 = collect_nodes(head2)
        nodes2[-1].next = nodes2[0]
        self.assertTrue(has_cycle(head2))
        self.assertFalse(has_cycle(from_list([1])))
        self.assertFalse(has_cycle(None))

    def test_03_long_list_10000(self):
        head = from_list(range(10000))
        nodes = collect_nodes(head)
        self.assertFalse(has_cycle(head))
        nodes[-1].next = nodes[4567]
        self.assertTrue(has_cycle(head))
        nodes[-1].next = None

    def test_04_examples(self):
        for source, expected in [([1, 2, 3, 4], [1, 4, 2, 3]),
                                 ([1, 2, 3, 4, 5], [1, 5, 2, 4, 3]),
                                 ([1], [1]), ([1, 2], [1, 2])]:
            head = from_list(source)
            self.assertIsNone(reorder_list(head))
            self.assertEqual(to_list(head), expected)

    def test_04_random_and_node_identity(self):
        for n in list(range(1, 40)) + [50000]:
            source = list(range(1, n + 1))
            head = from_list(source)
            original = collect_nodes(head)
            id_map = node_values_by_id(original)
            reorder_list(head)
            new = collect_nodes(head)
            expected = []
            left, right = 0, len(source) - 1
            while left <= right:
                expected.append(source[left])
                if left != right:
                    expected.append(source[right])
                left += 1
                right -= 1
            self.assertEqual([node.val for node in new], expected)
            self.assertEqual({id(node) for node in original}, {id(node) for node in new})
            self.assertEqual(node_values_by_id(new), id_map)

    def test_05_examples(self):
        head = from_list([4, 5, 1, 9])
        delete_node(head.next)
        self.assertEqual(to_list(head), [4, 1, 9])
        head2 = from_list([4, 5, 1, 9])
        delete_node(head2.next.next)
        self.assertEqual(to_list(head2), [4, 5, 9])

    def test_05_missing_tail_guard(self):
        head = from_list([1, 2])
        with self.assertRaises(ValueError):
            delete_node(head.next)

    def test_06_examples(self):
        self.assertEqual(to_list(double_it(from_list([1, 8, 9]))), [3, 7, 8])
        self.assertEqual(to_list(double_it(from_list([9, 9, 9]))), [1, 9, 9, 8])
        self.assertEqual(to_list(double_it(from_list([0]))), [0])

    def test_06_random_big_digits(self):
        for _ in range(150):
            digits = [self.rng.randint(1, 9)] + [self.rng.randint(0, 9) for _ in range(self.rng.randrange(80))]
            expected_digits = list(map(int, str(2 * int(''.join(map(str, digits))))))
            self.assertEqual(to_list(double_it(from_list(digits))), expected_digits)
        self.assertEqual(to_list(double_it(from_list([9] * 10000)), max_nodes=10001),
                         [1] + [9] * 9999 + [8])

    def test_07_examples(self):
        self.assertEqual(to_list(merge_k_lists([from_list(x) for x in [[1, 4, 5], [1, 3, 4], [2, 6]]])),
                         [1, 1, 2, 3, 4, 4, 5, 6])
        self.assertIsNone(merge_k_lists([]))
        self.assertIsNone(merge_k_lists([None]))

    def test_07_random_and_large_k(self):
        for _ in range(70):
            data = [sorted(self.rng.choices(range(-50, 51), k=self.rng.randrange(8))) for _ in range(self.rng.randrange(26))]
            heads = [from_list(row) for row in data]
            before = [node for h in heads for node in collect_nodes(h)]
            result = merge_k_lists(heads)
            self.assertEqual(to_list(result), sorted(v for row in data for v in row))
            self.assertEqual({id(n) for n in before}, {id(n) for n in collect_nodes(result)})
        self.assertEqual(to_list(merge_k_lists([from_list([i]) for i in range(10000)])),
                         list(range(10000)))

    def test_08_examples(self):
        source = [1, 2, 3, 4, 5]
        self.assertEqual(to_list(reverse_k_group(from_list(source), 2)), [2, 1, 4, 3, 5])
        self.assertEqual(to_list(reverse_k_group(from_list(source), 3)), [3, 2, 1, 4, 5])
        self.assertEqual(to_list(reverse_k_group(from_list(source), 1)), source)

    def test_08_random_and_no_value_mutation(self):
        for _ in range(100):
            n = self.rng.randint(1, 80)
            k = self.rng.randint(1, n)
            head = from_list(list(range(n)))
            before = collect_nodes(head)
            id_map = node_values_by_id(before)
            result = reverse_k_group(head, k)
            after = collect_nodes(result)
            expected = [value for start in range(0, n, k)
                        for value in (list(range(start, start + k))[::-1] if start + k <= n else list(range(start, n)))]
            self.assertEqual([node.val for node in after], expected)
            self.assertEqual({id(node) for node in after}, {id(node) for node in before})
            self.assertEqual(node_values_by_id(after), id_map)
        self.assertEqual(to_list(reverse_k_group(from_list(range(5000)), 5000)), list(reversed(range(5000))))

    def test_09_examples(self):
        self.assertEqual(to_list(partition_list(from_list([1, 4, 3, 2, 5, 2]), 3)),
                         [1, 2, 2, 4, 3, 5])
        self.assertEqual(to_list(partition_list(from_list([2, 1]), 2)), [1, 2])
        self.assertIsNone(partition_list(None, 0))

    def test_09_random_and_stability(self):
        for _ in range(100):
            source = [self.rng.randint(-100, 100) for _ in range(self.rng.randrange(201))]
            x = self.rng.randint(-200, 200)
            head = from_list(source)
            original = collect_nodes(head)
            id_map = node_values_by_id(original)
            result = partition_list(head, x)
            result_nodes = collect_nodes(result)
            self.assertEqual([node.val for node in result_nodes],
                             [v for v in source if v < x] + [v for v in source if v >= x])
            self.assertEqual([id(n) for n in result_nodes],
                             [id(n) for n in original if n.val < x] + [id(n) for n in original if n.val >= x])
            self.assertEqual(node_values_by_id(result_nodes), id_map)

    def test_all_in_one_independent(self):
        import all_solutions as s
        h = s.from_list([1, 2, 3, 4, 5])
        s.reorder_list(h)
        self.assertEqual(s.to_list(h), [1, 5, 2, 4, 3])
        self.assertEqual(s.to_list(s.merge_k_lists([s.from_list([1, 5]), s.from_list([2, 4])])),
                         [1, 2, 4, 5])
        self.assertEqual(s.to_list(s.reverse_k_group(s.from_list([1, 2, 3]), 2)), [2, 1, 3])


if __name__ == '__main__':
    unittest.main(verbosity=2)
