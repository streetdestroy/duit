"""Перевірки для всіх п'яти завдань без циклів."""
from solutions import (
    reverse_string, ListNode, swap_pairs, build_list, list_values,
    fibonacci, climb_stairs, my_pow,
)

# 1
assert reverse_string("tiger") == "regit"
assert reverse_string("") == ""
assert reverse_string("a") == "a"

# 2: звичайний, порожній, один вузол, непарна кількість вузлів
assert list_values(swap_pairs(build_list([1, 2, 3, 4]))) == [2, 1, 4, 3]
assert list_values(swap_pairs(build_list([]))) == []
assert list_values(swap_pairs(build_list([1]))) == [1]
assert list_values(swap_pairs(build_list([1, 2, 3]))) == [2, 1, 3]
first = ListNode(11)
second = ListNode(22)
first.next = second
new_head = swap_pairs(first)
assert new_head is second and new_head.next is first
assert first.val == 11 and second.val == 22

# 3
assert fibonacci(0) == 0
assert fibonacci(1) == 1
assert fibonacci(2) == 1
assert fibonacci(3) == 2
assert fibonacci(4) == 3
assert fibonacci(10) == 55

# 4
assert climb_stairs(1) == 1
assert climb_stairs(2) == 2
assert climb_stairs(3) == 3
assert climb_stairs(45) == 1836311903

# 5
assert abs(my_pow(2.0, 10) - 1024.0) < 1e-9
assert abs(my_pow(2.1, 3) - 9.261) < 1e-9
assert abs(my_pow(2.0, -2) - 0.25) < 1e-9
assert my_pow(0.0, 3) == 0.0
assert my_pow(-2.0, 3) == -8.0
assert my_pow(1.0, -2147483648) == 1.0
assert my_pow(2.0, 0) == 1.0

print("Усі перевірки завдань 1–5 успішні.")
