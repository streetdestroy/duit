# Масиви — 10 задач

**Дисципліна:** програмування, практичні завдання «Масиви»  
**Студент:** Паньків Даніїл Васильович  
**Група:** ІПЗ-4  
**Варіант:** №17 (у формі немає окремого розподілу завдань за варіантами)

**Швидкий варіант:** `all_solutions.py` містить усі 10 функцій в одному файлі; окремі файли нижче дублюють їх для зручної перевірки.

## Виконані завдання

| № | Файл | Функція | Часова складність |
|---|---|---|---|
| 1 | `task01_max_ones.py` | `find_max_consecutive_ones(nums)` | O(n) |
| 2 | `task02_even_digits.py` | `find_numbers(nums)` | O(n log M) |
| 3 | `task03_sorted_squares.py` | `sorted_squares(nums)` | O(n) |
| 4 | `task04_duplicate_zeros.py` | `duplicate_zeros(arr)` | O(n) |
| 5 | `task05_merge_sorted.py` | `merge(nums1, m, nums2, n)` | O(m+n) |
| 6 | `task06_remove_duplicates.py` | `remove_duplicates(nums)` | O(n) |
| 7 | `task07_double_exists.py` | `check_if_exist(arr)` | O(n) в середньому |
| 8 | `task08_mountain.py` | `valid_mountain_array(arr)` | O(n) |
| 9 | `task09_replace_right_max.py` | `replace_elements(arr)` | O(n) |
| 10 | `task10_sort_parity.py` | `sort_array_by_parity(nums)` | O(n) |

Завдання 4 та 5 **змінюють вхідний масив на місці** та не повертають масив. Завдання 6 повертає кількість унікальних елементів `k`, які займають перші `k` позицій початкового масиву. Завдання 9 та 10 повертають змінений масив.

## Як запустити

Потрібен Python 3.9 або новіший. Сторонні бібліотеки не потрібні.

З папки `arrays`:

```powershell
python task01_max_ones.py
python task02_even_digits.py
python task03_sorted_squares.py
python task04_duplicate_zeros.py
python task05_merge_sorted.py
python task06_remove_duplicates.py
python task07_double_exists.py
python task08_mountain.py
python task09_replace_right_max.py
python task10_sort_parity.py
```

Запуск усіх автоматизованих тестів:

```powershell
python -m unittest -v test_solutions.py
```

## Передача роботи

У відкритому репозиторії `streetdestroy/duit` створити папку `arrays` і розмістити в ній усі файли цієї роботи. У Google-формі в полі «Посилання на код в репозиторії» вказати посилання на папку `arrays` **після фактичного завантаження**. 
