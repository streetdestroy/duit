"""№4. Перевпорядкування L0, Ln, L1, Ln-1 ... зміною next-посилань."""
from common import ListNode


def reorder_list(head: ListNode | None) -> None:
    """Змінює список на місці, нічого не повертає (як у LeetCode)."""
    if head is None or head.next is None:
        return

    # 1. Знайти кінець першої половини.
    slow = fast = head
    while fast.next is not None and fast.next.next is not None:
        slow = slow.next
        fast = fast.next.next

    # 2. Розвернути другу половину.
    second = slow.next
    slow.next = None
    previous = None
    while second is not None:
        following = second.next
        second.next = previous
        previous = second
        second = following

    # 3. Почергово приєднати вузли обох половин.
    first, second = head, previous
    while second is not None:
        first_next, second_next = first.next, second.next
        first.next = second
        second.next = first_next
        first, second = first_next, second_next
