"""Завдання 6. Видалення дублікатів відсортованого масиву на місці."""


def remove_duplicates(nums: list[int]) -> int:
    """Повертає k: у перших k позиціях nums будуть унікальні елементи."""
    if not nums:
        return 0
    k = 1
    for i in range(1, len(nums)):
        if nums[i] != nums[k - 1]:
            nums[k] = nums[i]
            k += 1
    return k


if __name__ == "__main__":
    a = [1, 1, 2]
    k = remove_duplicates(a)
    print(k, a[:k])  # 2 [1, 2]
    a = [0, 0, 1, 1, 1, 2, 2, 3, 3, 4]
    k = remove_duplicates(a)
    print(k, a[:k])  # 5 [0, 1, 2, 3, 4]
