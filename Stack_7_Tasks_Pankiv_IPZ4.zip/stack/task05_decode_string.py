"""Завдання 5. Декодування k[рядок] з вкладеними групами."""


def decode_string(s: str) -> str:
    stack = []                  # (текст до групи, кількість повторів)
    current = ''
    count = 0
    for ch in s:
        if ch.isdigit():
            count = count * 10 + int(ch)
        elif ch == '[':
            stack.append((current, count))
            current = ''
            count = 0
        elif ch == ']':
            prefix, times = stack.pop()
            current = prefix + current * times
        else:
            current += ch
    return current


class Solution:
    def decodeString(self, s: str) -> str:
        return decode_string(s)
