"""Завдання 3: кількість запитів за останні 3000 мс включно."""
from collections import deque


class RecentCounter:
    def __init__(self):
        self._timestamps = deque()

    def ping(self, t: int) -> int:
        self._timestamps.append(t)
        while self._timestamps and self._timestamps[0] < t - 3000:
            self._timestamps.popleft()
        return len(self._timestamps)
