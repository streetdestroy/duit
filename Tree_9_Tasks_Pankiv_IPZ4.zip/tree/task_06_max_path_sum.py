"""Завдання 6. Максимальна сума шляху у дереві.

Ітеративний postorder не обмежується глибиною рекурсії Python.
Час O(n), пам'ять O(n).
"""
from common import TreeNode


def maxPathSum(root: TreeNode) -> int:
    if root is None:
        raise ValueError('За умовою дерево має бути непорожнім')

    best = float('-inf')
    gain = {}  # максимальна сума шляху від вузла вниз
    stack = [(root, False)]
    while stack:
        node, visited = stack.pop()
        if node is None:
            continue
        if not visited:
            stack.append((node, True))
            stack.append((node.right, False))
            stack.append((node.left, False))
            continue
        left = max(0, gain.get(node.left, 0))
        right = max(0, gain.get(node.right, 0))
        best = max(best, node.val + left + right)
        gain[node] = node.val + max(left, right)
    return int(best)
