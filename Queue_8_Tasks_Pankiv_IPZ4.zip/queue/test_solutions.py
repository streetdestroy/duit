"""Автотести: приклади з форми, властивості та випадкові перевірки."""
import random
import unittest
from collections import Counter, deque

from all_solutions import (
    firstUniqChar, MyStack, RecentCounter, MyCircularDeque,
    MyCircularQueue, movesToStamp, maxSlidingWindow, constrainedSubsetSum,
)


def apply_stamps(stamp, length, moves):
    output = ['?'] * length
    for start in moves:
        assert 0 <= start <= length - len(stamp)
        output[start: start + len(stamp)] = list(stamp)
    return ''.join(output)


class QueueTasksTest(unittest.TestCase):
    def test_01_examples(self):
        self.assertEqual(firstUniqChar('leopard'), 0)
        self.assertEqual(firstUniqChar('loveleopard'), 2)
        self.assertEqual(firstUniqChar('aabb'), -1)

    def test_01_random_and_long(self):
        rng = random.Random(17)
        for _ in range(300):
            s = ''.join(rng.choices('abcde', k=rng.randrange(1, 100)))
            f = Counter(s)
            expected = next((i for i, c in enumerate(s) if f[c] == 1), -1)
            self.assertEqual(firstUniqChar(s), expected)
        self.assertEqual(firstUniqChar('a' * 99999 + 'z'), 99999)

    def test_02_example(self):
        stack = MyStack()
        self.assertTrue(stack.empty())
        stack.push(1)
        stack.push(2)
        self.assertEqual(stack.top(), 2)
        self.assertEqual(stack.pop(), 2)
        self.assertFalse(stack.empty())
        self.assertEqual(stack.top(), 1)

    def test_02_random(self):
        rng = random.Random(37)
        s = MyStack()
        ref = []
        for _ in range(200):
            if not ref or rng.random() < 0.6:
                n = rng.randrange(1, 10)
                s.push(n); ref.append(n)
            else:
                if rng.random() < 0.5:
                    self.assertEqual(s.top(), ref[-1])
                else:
                    self.assertEqual(s.pop(), ref.pop())
            self.assertEqual(s.empty(), not ref)

    def test_03_example_and_bounds(self):
        r = RecentCounter()
        self.assertEqual([r.ping(x) for x in [1,100,3001,3002]], [1,2,3,3])
        self.assertEqual(r.ping(6002), 2)  # [3002,6002] включно
        self.assertEqual(r.ping(6003), 2)  # [6002, 6003]

    def test_03_random_and_long(self):
        rng = random.Random(41)
        r = RecentCounter()
        ref = []
        t = 0
        for _ in range(10000):
            t += rng.randint(1,200)
            ref.append(t)
            while ref and ref[0] < t - 3000:
                ref.pop(0)
            self.assertEqual(r.ping(t), len(ref))

    def test_04_example(self):
        d = MyCircularDeque(3)
        values = [d.insertLast(1),d.insertLast(2),d.insertFront(3),d.insertFront(4),
                  d.getRear(),d.isFull(),d.deleteLast(),d.insertFront(4),d.getFront()]
        self.assertEqual(values,[True,True,True,False,2,True,True,True,4])

    def test_04_random(self):
        rng = random.Random(51)
        for capacity in (1,2,3,10):
            d = MyCircularDeque(capacity)
            ref = deque()
            for _ in range(3000):
                action = rng.randrange(8)
                if action in (0,1):
                    value = rng.randint(0,1000)
                    ok = len(ref) < capacity
                    if action == 0:
                        self.assertEqual(d.insertFront(value),ok)
                        if ok: ref.appendleft(value)
                    else:
                        self.assertEqual(d.insertLast(value),ok)
                        if ok: ref.append(value)
                elif action == 2:
                    self.assertEqual(d.deleteFront(),bool(ref))
                    if ref: ref.popleft()
                elif action == 3:
                    self.assertEqual(d.deleteLast(),bool(ref))
                    if ref: ref.pop()
                elif action == 4:
                    self.assertEqual(d.getFront(),ref[0] if ref else -1)
                elif action == 5:
                    self.assertEqual(d.getRear(),ref[-1] if ref else -1)
                elif action == 6:
                    self.assertEqual(d.isEmpty(),not ref)
                else:
                    self.assertEqual(d.isFull(),len(ref)==capacity)

    def test_05_example(self):
        q=MyCircularQueue(3)
        values=[q.enQueue(1),q.enQueue(2),q.enQueue(3),q.enQueue(4),
                q.Rear(),q.isFull(),q.deQueue(),q.enQueue(4),q.Rear()]
        self.assertEqual(values,[True,True,True,False,3,True,True,True,4])

    def test_05_random(self):
        rng = random.Random(62)
        for capacity in (1,2,3,20):
            q=MyCircularQueue(capacity)
            ref=deque()
            for _ in range(3000):
                action=rng.randrange(6)
                if action==0:
                    val=rng.randrange(0,1001)
                    ok=len(ref)<capacity
                    self.assertEqual(q.enQueue(val),ok)
                    if ok:ref.append(val)
                elif action==1:
                    self.assertEqual(q.deQueue(),bool(ref))
                    if ref:ref.popleft()
                elif action==2:
                    self.assertEqual(q.Front(),ref[0] if ref else -1)
                elif action==3:
                    self.assertEqual(q.Rear(),ref[-1] if ref else -1)
                elif action==4:
                    self.assertEqual(q.isEmpty(),not ref)
                else:
                    self.assertEqual(q.isFull(),len(ref)==capacity)

    def test_06_examples(self):
        for stamp, target in [('abc','ababc'),('abca','aabcaca'),('abc','abc')]:
            moves=movesToStamp(stamp,target)
            self.assertTrue(moves)
            self.assertLessEqual(len(moves),10*len(target))
            self.assertEqual(apply_stamps(stamp,len(target),moves),target)
        self.assertEqual(movesToStamp('abc','abzabc'),[])

    def test_06_generated_reachable_random(self):
        rng=random.Random(77)
        for _ in range(250):
            m=rng.randint(1,5)
            n=rng.randint(m,12)
            stamp=''.join(rng.choices('abc',k=m))
            # Щоб кожна позиція була заповнена, ставимо штампи від 0 до n-m,
            # а потім перезаписуємо деякі позиції.
            moves=list(range(n-m+1))
            moves += [rng.randrange(n-m+1) for _ in range(rng.randrange(0,10))]
            target=apply_stamps(stamp,n,moves)
            solution=movesToStamp(stamp,target)
            self.assertTrue(solution,(stamp,target))
            self.assertLessEqual(len(solution),10*n)
            self.assertEqual(apply_stamps(stamp,n,solution),target)

    def test_06_max_length(self):
        stamp='abc'
        target='abc'*333+'a'  # 1000 символів, останній 'a' недосяжний без перезапису?
        result=movesToStamp(stamp,target)
        if result:
            self.assertEqual(apply_stamps(stamp,len(target),result),target)

    def test_07_examples(self):
        self.assertEqual(maxSlidingWindow([1,3,-1,-3,5,3,6,7],3),[3,3,5,5,6,7])
        self.assertEqual(maxSlidingWindow([1],1),[1])
        self.assertEqual(maxSlidingWindow([-7,-2,-8],3),[-2])

    def test_07_random_and_long(self):
        rng=random.Random(18)
        for _ in range(250):
            nums=[rng.randint(-20,20) for _ in range(rng.randint(1,80))]
            k=rng.randint(1,len(nums))
            expected=[max(nums[i:i+k]) for i in range(len(nums)-k+1)]
            self.assertEqual(maxSlidingWindow(nums,k),expected)
        self.assertEqual(maxSlidingWindow(list(range(100000)),10000),list(range(9999,100000)))

    def test_08_examples(self):
        self.assertEqual(constrainedSubsetSum([10,2,-10,5,20],2),37)
        self.assertEqual(constrainedSubsetSum([-1,-2,-3],1),-1)
        self.assertEqual(constrainedSubsetSum([10,-2,-10,-5,20],2),23)

    def test_08_random_and_long(self):
        rng=random.Random(19)
        for _ in range(350):
            nums=[rng.randint(-20,20) for _ in range(rng.randint(1,80))]
            k=rng.randint(1,len(nums))
            dp=[0]*len(nums)
            for i,v in enumerate(nums):
                dp[i]=v+max([0]+dp[max(0,i-k):i])
            self.assertEqual(constrainedSubsetSum(nums,k),max(dp))
        self.assertEqual(constrainedSubsetSum([1]*100000,100000),100000)
        self.assertEqual(constrainedSubsetSum([-10]*100000,1),-10)

if __name__=='__main__':
    unittest.main(verbosity=2)
