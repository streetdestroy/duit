"""Завдання 3. MinStack: усі операції O(1) за часом."""


class MinStack:
    def __init__(self):
        # Кожен елемент: (значення, мінімум серед елементів до цієї позиції).
        self._data = []

    def push(self, val: int) -> None:
        current_min = val if not self._data else min(val, self._data[-1][1])
        self._data.append((val, current_min))

    def pop(self) -> None:
        self._data.pop()

    def top(self) -> int:
        return self._data[-1][0]

    def getMin(self) -> int:
        return self._data[-1][1]
