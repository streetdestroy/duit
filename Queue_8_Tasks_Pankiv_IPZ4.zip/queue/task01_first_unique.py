"""Завдання 1: перший неповторюваний символ у рядку."""

def firstUniqChar(s: str) -> int:
    frequencies = [0] * 26
    for ch in s:
        frequencies[ord(ch) - ord('a')] += 1
    for index, ch in enumerate(s):
        if frequencies[ord(ch) - ord('a')] == 1:
            return index
    return -1


class Solution:
    def firstUniqChar(self, s: str) -> int:
        return firstUniqChar(s)
