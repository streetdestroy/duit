"""Завдання 6 (№5 у формі): штампування послідовності.

Розв'язок у зворотному напрямку: стираємо допустимі фрагменти,
після чого розвертаємо порядок ходів. Складність O(m*n).
"""
from collections import deque


def movesToStamp(stamp: str, target: str) -> list[int]:
    m, n = len(stamp), len(target)
    if m > n:
        return []
    # dependents[p]: усі вікна, де символ у позиції p спочатку не збігається
    # із символом штампа. Коли p «стерто», відповідна невідповідність зникає.
    dependents = [[] for _ in range(n)]
    unresolved = [0] * (n - m + 1)
    for start in range(n - m + 1):
        for j, expected in enumerate(stamp):
            if target[start + j] != expected:
                unresolved[start] += 1
                dependents[start + j].append(start)

    ready = deque(i for i, count in enumerate(unresolved) if count == 0)
    erased = [False] * n
    result_reverse = []
    while ready:
        start = ready.popleft()
        result_reverse.append(start)
        for p in range(start, start + m):
            if erased[p]:
                continue
            erased[p] = True
            for affected in dependents[p]:
                unresolved[affected] -= 1
                if unresolved[affected] == 0:
                    ready.append(affected)

    if not all(erased) or len(result_reverse) > 10 * n:
        return []
    result_reverse.reverse()
    return result_reverse


class Solution:
    def movesToStamp(self, stamp: str, target: str) -> list[int]:
        return movesToStamp(stamp, target)
