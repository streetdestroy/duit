"""Масиви — 10 задач. Студент: Паньків Даніїл Васильович, ІПЗ-4."""

# Завдання 1: task01_max_ones
def find_max_consecutive_ones(nums: list[int]) -> int:
    current = 0
    maximum = 0
    for value in nums:
        if value == 1:
            current += 1
            if current > maximum:
                maximum = current
        else:
            current = 0
    return maximum

# Завдання 2: task02_even_digits
def find_numbers(nums: list[int]) -> int:
    result = 0
    for value in nums:
        count = 0
        while value > 0:
            value //= 10
            count += 1
        if count % 2 == 0:
            result += 1
    return result

# Завдання 3: task03_sorted_squares
def sorted_squares(nums: list[int]) -> list[int]:
    n = len(nums)
    answer = [0] * n
    left, right = 0, n - 1
    for pos in range(n - 1, -1, -1):
        if abs(nums[left]) > abs(nums[right]):
            answer[pos] = nums[left] * nums[left]
            left += 1
        else:
            answer[pos] = nums[right] * nums[right]
            right -= 1
    return answer

# Завдання 4: task04_duplicate_zeros
def duplicate_zeros(arr: list[int]) -> None:
    """Змінює arr на місці, зберігаючи початкову довжину."""
    n = len(arr)
    zeros = 0
    for value in arr:
        if value == 0:
            zeros += 1

    write = n + zeros - 1
    for read in range(n - 1, -1, -1):
        if write < n:
            arr[write] = arr[read]
        if arr[read] == 0:
            write -= 1
            if write < n:
                arr[write] = 0
        write -= 1

# Завдання 5: task05_merge_sorted
def merge(nums1: list[int], m: int, nums2: list[int], n: int) -> None:
    """Змінює nums1 на місці та нічого не повертає."""
    i = m - 1
    j = n - 1
    k = m + n - 1
    while j >= 0:
        if i >= 0 and nums1[i] > nums2[j]:
            nums1[k] = nums1[i]
            i -= 1
        else:
            nums1[k] = nums2[j]
            j -= 1
        k -= 1

# Завдання 6: task06_remove_duplicates
def remove_duplicates(nums: list[int]) -> int:
    """Повертає k: у перших k позиціях nums будуть унікальні елементи."""
    if not nums:
        return 0
    k = 1
    for i in range(1, len(nums)):
        if nums[i] != nums[k - 1]:
            nums[k] = nums[i]
            k += 1
    return k

# Завдання 7: task07_double_exists
def check_if_exist(arr: list[int]) -> bool:
    seen: set[int] = set()
    for number in arr:
        # Перевірка до додавання у seen виключає використання одного індексу двічі.
        if number * 2 in seen or (number % 2 == 0 and number // 2 in seen):
            return True
        seen.add(number)
    return False

# Завдання 8: task08_mountain
def valid_mountain_array(arr: list[int]) -> bool:
    n = len(arr)
    if n < 3:
        return False
    i = 0
    while i + 1 < n and arr[i] < arr[i + 1]:
        i += 1
    if i == 0 or i == n - 1:
        return False
    while i + 1 < n and arr[i] > arr[i + 1]:
        i += 1
    return i == n - 1

# Завдання 9: task09_replace_right_max
def replace_elements(arr: list[int]) -> list[int]:
    best_right = -1
    for i in range(len(arr) - 1, -1, -1):
        original = arr[i]
        arr[i] = best_right
        if original > best_right:
            best_right = original
    return arr

# Завдання 10: task10_sort_parity
def sort_array_by_parity(nums: list[int]) -> list[int]:
    left, right = 0, len(nums) - 1
    while left < right:
        if nums[left] % 2 == 0:
            left += 1
        elif nums[right] % 2 == 1:
            right -= 1
        else:
            nums[left], nums[right] = nums[right], nums[left]
            left += 1
            right -= 1
    return nums
