"""Завдання 1. Те саме дерево. Час O(n), пам'ять O(h..n)."""
from common import TreeNode


def isSameTree(p: TreeNode | None, q: TreeNode | None) -> bool:
    """Дерева однакові тоді й лише тоді, коли збігаються вузли й структура."""
    stack = [(p, q)]
    while stack:
        first, second = stack.pop()
        if first is None or second is None:
            if first is not second:
                return False
            continue
        if first.val != second.val:
            return False
        stack.append((first.left, second.left))
        stack.append((first.right, second.right))
    return True
