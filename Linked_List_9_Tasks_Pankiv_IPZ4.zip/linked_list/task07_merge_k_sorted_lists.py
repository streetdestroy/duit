"""№7. Злиття k відсортованих списків попарно, O(N log k)."""
from common import ListNode
from task01_merge_two_sorted_lists import merge_two_lists


def merge_k_lists(lists: list[ListNode | None]) -> ListNode | None:
    if not lists:
        return None
    # Копія лише масиву посилань; вузли залишаються тими самими.
    heads = list(lists)
    interval = 1
    while interval < len(heads):
        for index in range(0, len(heads) - interval, interval * 2):
            heads[index] = merge_two_lists(heads[index], heads[index + interval])
        interval *= 2
    return heads[0]
