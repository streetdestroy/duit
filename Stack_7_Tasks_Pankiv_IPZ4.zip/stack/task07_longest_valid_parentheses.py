"""Завдання 7. Найдовший коректний підрядок дужок: O(n) часу."""


def longest_valid_parentheses(s: str) -> int:
    stack = [-1]  # Індекс останньої некоректної ')' або межі рядка.
    best = 0
    for index, ch in enumerate(s):
        if ch == '(':
            stack.append(index)
        else:
            stack.pop()
            if stack:
                best = max(best, index - stack[-1])
            else:
                stack.append(index)
    return best


class Solution:
    def longestValidParentheses(self, s: str) -> int:
        return longest_valid_parentheses(s)
