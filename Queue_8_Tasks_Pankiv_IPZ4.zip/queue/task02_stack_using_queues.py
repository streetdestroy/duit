"""Завдання 2: стек LIFO на основі двох черг FIFO."""
from collections import deque


class MyStack:
    def __init__(self):
        self._main = deque()
        self._buffer = deque()

    def push(self, x: int) -> None:
        self._buffer.append(x)
        while self._main:
            self._buffer.append(self._main.popleft())
        self._main, self._buffer = self._buffer, self._main

    def pop(self) -> int:
        return self._main.popleft()

    def top(self) -> int:
        return self._main[0]

    def empty(self) -> bool:
        return not self._main
