"""Завдання 4 (повторний №3 у формі): кільцева двостороння черга.

Операції O(1). Тільки власний кільцевий буфер на масиві.
"""

class MyCircularDeque:
    def __init__(self, k: int):
        if k < 1:
            raise ValueError('k must be positive')
        self._data = [0] * k
        self._capacity = k
        self._head = 0
        self._size = 0

    def insertFront(self, value: int) -> bool:
        if self.isFull():
            return False
        self._head = (self._head - 1) % self._capacity
        self._data[self._head] = value
        self._size += 1
        return True

    def insertLast(self, value: int) -> bool:
        if self.isFull():
            return False
        tail = (self._head + self._size) % self._capacity
        self._data[tail] = value
        self._size += 1
        return True

    def deleteFront(self) -> bool:
        if self.isEmpty():
            return False
        self._head = (self._head + 1) % self._capacity
        self._size -= 1
        return True

    def deleteLast(self) -> bool:
        if self.isEmpty():
            return False
        self._size -= 1
        return True

    def getFront(self) -> int:
        return -1 if self.isEmpty() else self._data[self._head]

    def getRear(self) -> int:
        return -1 if self.isEmpty() else self._data[(self._head + self._size - 1) % self._capacity]

    def isEmpty(self) -> bool:
        return self._size == 0

    def isFull(self) -> bool:
        return self._size == self._capacity
