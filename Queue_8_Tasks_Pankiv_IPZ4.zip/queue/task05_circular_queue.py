"""Завдання 5 (№4 у формі): циклічна черга FIFO без готової черги."""

class MyCircularQueue:
    def __init__(self, k: int):
        if k < 1:
            raise ValueError('k must be positive')
        self._data = [0] * k
        self._capacity = k
        self._head = 0
        self._size = 0

    def enQueue(self, value: int) -> bool:
        if self.isFull():
            return False
        index = (self._head + self._size) % self._capacity
        self._data[index] = value
        self._size += 1
        return True

    def deQueue(self) -> bool:
        if self.isEmpty():
            return False
        self._head = (self._head + 1) % self._capacity
        self._size -= 1
        return True

    def Front(self) -> int:
        return -1 if self.isEmpty() else self._data[self._head]

    def Rear(self) -> int:
        return -1 if self.isEmpty() else self._data[(self._head + self._size - 1) % self._capacity]

    def isEmpty(self) -> bool:
        return self._size == 0

    def isFull(self) -> bool:
        return self._size == self._capacity
