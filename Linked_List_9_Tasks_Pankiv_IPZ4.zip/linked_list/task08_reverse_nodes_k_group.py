"""№8. Розвернути вузли по k, не торкаючись значень вузлів."""
from common import ListNode


def reverse_k_group(head: ListNode | None, k: int) -> ListNode | None:
    if k <= 1 or head is None:
        return head
    dummy = ListNode(0, head)
    before_group = dummy
    while True:
        # Перевірити, чи вистачає k вузлів для чергової групи.
        kth = before_group
        for _ in range(k):
            kth = kth.next
            if kth is None:
                return dummy.next

        after_group = kth.next
        previous = after_group
        current = before_group.next
        while current is not after_group:
            following = current.next
            current.next = previous
            previous = current
            current = following

        # Початок старої групи став її останнім вузлом.
        old_start = before_group.next
        before_group.next = kth
        before_group = old_start
