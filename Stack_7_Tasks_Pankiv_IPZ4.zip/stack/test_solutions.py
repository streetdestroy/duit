"""Тести стандартної бібліотеки unittest. Запуск: python -m unittest -v."""
import itertools
import random
import unittest
from collections import deque
from all_solutions import (TreeNode, MinStack, MyQueue, is_valid, inorder_traversal,
                           decode_string, eval_rpn, longest_valid_parentheses)


class StackTasksTests(unittest.TestCase):
    def test_01_examples(self):
        self.assertTrue(is_valid('()'))
        self.assertTrue(is_valid('()[]{}'))
        self.assertFalse(is_valid('(]'))

    def test_01_nested_and_invalid(self):
        self.assertTrue(is_valid('{[()()]}'))
        self.assertFalse(is_valid('([)]'))
        self.assertFalse(is_valid('('))
        self.assertFalse(is_valid(']'))
        self.assertTrue(is_valid(''))
        self.assertTrue(is_valid('(' * 5000 + ')' * 5000))

    def test_02_examples(self):
        self.assertEqual(inorder_traversal(TreeNode(1, None, TreeNode(2, TreeNode(3)))), [1,3,2])
        self.assertEqual(inorder_traversal(None), [])
        self.assertEqual(inorder_traversal(TreeNode(1)), [1])

    def test_02_left_right_and_unbalanced(self):
        node = TreeNode(5, TreeNode(2, TreeNode(1), TreeNode(3)), TreeNode(7))
        self.assertEqual(inorder_traversal(node), [1,2,3,5,7])
        root = TreeNode(0)
        node = root
        for x in range(1, 100):
            node.left = TreeNode(x)
            node = node.left
        self.assertEqual(inorder_traversal(root), list(reversed(range(100))))

    def test_03_example(self):
        stack=MinStack()
        for n in [-2,0,-3]: stack.push(n)
        self.assertEqual(stack.getMin(), -3)
        stack.pop()
        self.assertEqual(stack.top(), 0)
        self.assertEqual(stack.getMin(), -2)

    def test_03_duplicate_min(self):
        stack = MinStack()
        for n in [5,2,2,7,-1,-1]: stack.push(n)
        self.assertEqual(stack.getMin(), -1)
        stack.pop()
        self.assertEqual(stack.getMin(), -1)
        stack.pop()
        self.assertEqual(stack.getMin(), 2)
        stack.pop()
        self.assertEqual(stack.getMin(), 2)

    def test_03_random_operations(self):
        rng = random.Random(17)
        stack = MinStack()
        baseline=[]
        for i in range(2000):
            if not baseline or rng.random()<0.6:
                v=rng.randint(-500,500)
                baseline.append(v)
                stack.push(v)
            else:
                stack.pop()
                baseline.pop()
            if baseline:
                self.assertEqual(stack.getMin(),min(baseline))
                self.assertEqual(stack.top(),baseline[-1])

    def test_04_example(self):
        q=MyQueue()
        q.push(1)
        q.push(2)
        self.assertEqual(q.peek(),1)
        self.assertEqual(q.pop(),1)
        self.assertFalse(q.empty())
        self.assertEqual(q.pop(),2)
        self.assertTrue(q.empty())

    def test_04_random_operations(self):
        rng = random.Random(42)
        q=MyQueue()
        d=deque()
        for _ in range(800):
            if not d or rng.random()<0.6:
                v=rng.randint(1,9)
                q.push(v);d.append(v)
            elif rng.random()<0.5:
                self.assertEqual(q.peek(),d[0])
            else:
                self.assertEqual(q.pop(),d.popleft())
            self.assertEqual(q.empty(),not bool(d))

    def test_05_examples(self):
        self.assertEqual(decode_string('3[a]2[bc]'),'aaabcbc')
        self.assertEqual(decode_string('3[a2[c]]'),'accaccacc')
        self.assertEqual(decode_string('2[abc]3[cd]ef'),'abcabccdcdcdef')

    def test_05_multidigit_and_deep(self):
        self.assertEqual(decode_string('12[ab]'), 'ab'*12)
        self.assertEqual(decode_string('2[3[a]b]'), 'aaabaaab')
        self.assertEqual(decode_string('1000[a]'), 'a'*1000)
        self.assertEqual(decode_string('z'), 'z')

    def test_06_examples(self):
        self.assertEqual(eval_rpn(['2','1','+','3','*']),9)
        self.assertEqual(eval_rpn(['4','13','5','/','+']),6)
        self.assertEqual(eval_rpn(['10','6','9','3','+','-11','*','/','*','17','+','5','+']),22)

    def test_06_division_rounding(self):
        self.assertEqual(eval_rpn(['-7','3','/']),-2)
        self.assertEqual(eval_rpn(['7','-3','/']),-2)
        self.assertEqual(eval_rpn(['-7','-3','/']),2)
        self.assertEqual(eval_rpn(['0','-3','/']),0)
        self.assertEqual(eval_rpn(['8','3','-']),5)
        self.assertEqual(eval_rpn(['-15']),-15)

    def test_07_examples(self):
        self.assertEqual(longest_valid_parentheses('(()'),2)
        self.assertEqual(longest_valid_parentheses(')()())'),4)
        self.assertEqual(longest_valid_parentheses(''),0)

    def test_07_more(self):
        cases={'()':2,'(()())':6,')(':0,'()(()':2,'()(())':6,')(()())(':6,
               '((()))()':8,')())((()':2}
        for s,expected in cases.items():
            self.assertEqual(longest_valid_parentheses(s),expected,s)
        self.assertEqual(longest_valid_parentheses('('*15000+')'*15000),30000)

    def test_07_bruteforce_all_binary_strings(self):
        def brute(s):
            longest=0
            for i in range(len(s)):
                depth=0
                for j in range(i,len(s)):
                    depth += 1 if s[j]=='(' else -1
                    if depth < 0: break
                    if depth == 0: longest=max(longest,j-i+1)
            return longest
        for n in range(11):
            for chars in itertools.product('()',repeat=n):
                s=''.join(chars)
                self.assertEqual(longest_valid_parentheses(s),brute(s),s)


if __name__ == '__main__':
    unittest.main(verbosity=2)
