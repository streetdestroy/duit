"""Приклади запуску завдань 1–5. Лише рекурсивні розв'язки."""
from solutions import (
    print_reverse, ListNode, swap_pairs, build_list, list_values,
    fibonacci, climb_stairs, my_pow,
)


print("Завдання 1: reverse('tiger')")
print_reverse("tiger")

print("Завдання 2: [1, 2, 3, 4]")
head = build_list([1, 2, 3, 4])
print(list_values(swap_pairs(head)))

print("Завдання 3: F(2), F(3), F(4)")
print(fibonacci(2), fibonacci(3), fibonacci(4))

print("Завдання 4: n=2, n=3")
print(climb_stairs(2), climb_stairs(3))

print("Завдання 5: (2, 10), (2.1, 3), (2, -2)")
print(f"{my_pow(2.0, 10):.5f}")
print(f"{my_pow(2.1, 3):.5f}")
print(f"{my_pow(2.0, -2):.5f}")
