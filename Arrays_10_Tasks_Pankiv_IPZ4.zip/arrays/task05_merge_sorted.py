"""Завдання 5. Злиття двох відсортованих масивів у nums1."""


def merge(nums1: list[int], m: int, nums2: list[int], n: int) -> None:
    """Змінює nums1 на місці та нічого не повертає."""
    i = m - 1
    j = n - 1
    k = m + n - 1
    while j >= 0:
        if i >= 0 and nums1[i] > nums2[j]:
            nums1[k] = nums1[i]
            i -= 1
        else:
            nums1[k] = nums2[j]
            j -= 1
        k -= 1


if __name__ == "__main__":
    a = [1, 2, 3, 0, 0, 0]
    merge(a, 3, [2, 5, 6], 3)
    print(a)  # [1, 2, 2, 3, 5, 6]
    a = [1]
    merge(a, 1, [], 0)
    print(a)  # [1]
    a = [0]
    merge(a, 0, [1], 1)
    print(a)  # [1]
