"""№2. Видалення повторних вузлів із відсортованого списку."""
from common import ListNode


def delete_duplicates(head: ListNode | None) -> ListNode | None:
    current = head
    while current is not None and current.next is not None:
        if current.val == current.next.val:
            current.next = current.next.next
        else:
            current = current.next
    return head
