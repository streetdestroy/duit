"""Вузол однозв'язного списку та допоміжні функції для прикладів і тестів."""
from __future__ import annotations


class ListNode:
    def __init__(self, val: int = 0, next: ListNode | None = None):
        self.val = val
        self.next = next

    def __repr__(self) -> str:
        return f"ListNode({self.val})"


def from_list(values):
    """Створити однозв'язний список із послідовності чисел."""
    dummy = ListNode()
    tail = dummy
    for value in values:
        tail.next = ListNode(value)
        tail = tail.next
    return dummy.next


def to_list(head, max_nodes: int = 20000) -> list[int]:
    """Зібрати значення вузлів; захистити приклад від циклічного списку."""
    result = []
    seen = set()
    current = head
    while current is not None:
        if id(current) in seen:
            raise ValueError("Список містить цикл")
        if len(result) >= max_nodes:
            raise ValueError("Список перевищує допустиму довжину для виведення")
        seen.add(id(current))
        result.append(current.val)
        current = current.next
    return result
