"""№3. Перевірка на цикл алгоритмом Флойда (два покажчики)."""
from common import ListNode


def has_cycle(head: ListNode | None) -> bool:
    slow = fast = head
    while fast is not None and fast.next is not None:
        slow = slow.next
        fast = fast.next.next
        if slow is fast:
            return True
    return False
