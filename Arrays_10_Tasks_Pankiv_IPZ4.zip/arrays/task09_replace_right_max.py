"""Завдання 9. Заміна елементів максимумом праворуч."""


def replace_elements(arr: list[int]) -> list[int]:
    best_right = -1
    for i in range(len(arr) - 1, -1, -1):
        original = arr[i]
        arr[i] = best_right
        if original > best_right:
            best_right = original
    return arr


if __name__ == "__main__":
    print(replace_elements([17, 18, 5, 4, 6, 1]))  # [18, 6, 6, 6, 1, -1]
    print(replace_elements([400]))  # [-1]
