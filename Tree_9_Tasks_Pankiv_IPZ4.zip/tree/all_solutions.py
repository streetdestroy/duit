# Усі 9 завдань 'Дерева (Tree)' — Паньків Даніїл Васильович, ІПЗ-4

"""Допоміжні засоби для тестів і демонстрації бінарних дерев."""
from collections import deque
from typing import Optional


class TreeNode:
    """Вузол бінарного дерева у форматі LeetCode."""

    def __init__(self, val: int = 0,
                 left: Optional['TreeNode'] = None,
                 right: Optional['TreeNode'] = None):
        self.val = val
        self.left = left
        self.right = right


def build_tree(values: list) -> Optional[TreeNode]:
    """Створити дерево з level-order запису: [1, None, 2, 3]."""
    if not values or values[0] is None:
        return None
    root = TreeNode(values[0])
    queue = deque([root])
    index = 1
    while queue and index < len(values):
        parent = queue.popleft()
        if index < len(values):
            value = values[index]
            index += 1
            if value is not None:
                parent.left = TreeNode(value)
                queue.append(parent.left)
        if index < len(values):
            value = values[index]
            index += 1
            if value is not None:
                parent.right = TreeNode(value)
                queue.append(parent.right)
    return root


def tree_to_list(root: Optional[TreeNode]) -> list:
    """Перетворити дерево в level-order список без кінцевих None."""
    if root is None:
        return []
    values = []
    queue = deque([root])
    while queue:
        node = queue.popleft()
        if node is None:
            values.append(None)
        else:
            values.append(node.val)
            queue.append(node.left)
            queue.append(node.right)
    while values and values[-1] is None:
        values.pop()
    return values



# ======================================================================
# task_01_same_tree.py
# ======================================================================
"""Завдання 1. Те саме дерево. Час O(n), пам'ять O(h..n)."""


def isSameTree(p: TreeNode | None, q: TreeNode | None) -> bool:
    """Дерева однакові тоді й лише тоді, коли збігаються вузли й структура."""
    stack = [(p, q)]
    while stack:
        first, second = stack.pop()
        if first is None or second is None:
            if first is not second:
                return False
            continue
        if first.val != second.val:
            return False
        stack.append((first.left, second.left))
        stack.append((first.right, second.right))
    return True



# ======================================================================
# task_02_symmetric_tree.py
# ======================================================================
"""Завдання 2. Симетричне дерево. Час O(n), пам'ять O(n)."""


def isSymmetric(root: TreeNode | None) -> bool:
    if root is None:
        return True
    stack = [(root.left, root.right)]
    while stack:
        left, right = stack.pop()
        if left is None or right is None:
            if left is not right:
                return False
            continue
        if left.val != right.val:
            return False
        stack.append((left.left, right.right))
        stack.append((left.right, right.left))
    return True



# ======================================================================
# task_03_invert_tree.py
# ======================================================================
"""Завдання 3. Інвертувати бінарне дерево. Час O(n), пам'ять O(n)."""


def invertTree(root: TreeNode | None) -> TreeNode | None:
    if root is None:
        return None
    stack = [root]
    while stack:
        node = stack.pop()
        node.left, node.right = node.right, node.left
        if node.left is not None:
            stack.append(node.left)
        if node.right is not None:
            stack.append(node.right)
    return root



# ======================================================================
# task_04_kth_smallest.py
# ======================================================================
"""Завдання 4. K-й найменший у BST. Час O(h+k), пам'ять O(h)."""


def kthSmallest(root: TreeNode | None, k: int) -> int:
    """Ітеративний симетричний обхід BST: ліве піддерево -> вузол -> праве."""
    stack = []
    node = root
    while stack or node is not None:
        while node is not None:
            stack.append(node)
            node = node.left
        node = stack.pop()
        k -= 1
        if k == 0:
            return node.val
        node = node.right
    raise ValueError('k має бути в діапазоні від 1 до кількості вузлів')



# ======================================================================
# task_05_codec.py
# ======================================================================
"""Завдання 5. Серіалізація та десеріалізація дерева.

Власний формат: preorder (вузол, ліво, право), # = відсутній вузол.
Без глибокої рекурсії; O(n) часу й пам'яті.
"""


class Codec:
    def serialize(self, root: TreeNode | None) -> str:
        tokens = []
        stack = [root]
        while stack:
            node = stack.pop()
            if node is None:
                tokens.append('#')
            else:
                tokens.append(str(node.val))
                stack.append(node.right)
                stack.append(node.left)
        return ','.join(tokens)

    def deserialize(self, data: str) -> TreeNode | None:
        if not data or data == '#':
            return None
        tokens = iter(data.split(','))
        first = next(tokens)
        root = TreeNode(int(first))
        # У кадрі: (вузол, слот 0 = лівий; слот 1 = правий).
        stack = [(root, 0)]
        for token in tokens:
            if not stack:
                raise ValueError('Зайві токени в серіалізованому дереві')
            node, side = stack.pop()
            child = None if token == '#' else TreeNode(int(token))
            if side == 0:
                node.left = child
                stack.append((node, 1))
            else:
                node.right = child
            if child is not None:
                stack.append((child, 0))
        if stack:
            raise ValueError('Серіалізоване дерево обірване')
        return root



# ======================================================================
# task_06_max_path_sum.py
# ======================================================================
"""Завдання 6. Максимальна сума шляху у дереві.

Ітеративний postorder не обмежується глибиною рекурсії Python.
Час O(n), пам'ять O(n).
"""


def maxPathSum(root: TreeNode) -> int:
    if root is None:
        raise ValueError('За умовою дерево має бути непорожнім')

    best = float('-inf')
    gain = {}  # максимальна сума шляху від вузла вниз
    stack = [(root, False)]
    while stack:
        node, visited = stack.pop()
        if node is None:
            continue
        if not visited:
            stack.append((node, True))
            stack.append((node.right, False))
            stack.append((node.left, False))
            continue
        left = max(0, gain.get(node.left, 0))
        right = max(0, gain.get(node.right, 0))
        best = max(best, node.val + left + right)
        gain[node] = node.val + max(left, right)
    return int(best)



# ======================================================================
# task_07_cameras.py
# ======================================================================
"""Завдання 7. Мінімальна кількість камер.

Жадібний алгоритм, ітеративний postorder, O(n) часу та пам'яті.
"""


def minCameraCover(root: TreeNode | None) -> int:
    if root is None:
        return 0
    UNCOVERED, COVERED, CAMERA = 0, 1, 2
    state = {None: COVERED}
    cameras = 0
    stack = [(root, False)]
    while stack:
        node, visited = stack.pop()
        if node is None:
            continue
        if not visited:
            stack.append((node, True))
            stack.append((node.right, False))
            stack.append((node.left, False))
            continue
        left = state[node.left]
        right = state[node.right]
        if left == UNCOVERED or right == UNCOVERED:
            state[node] = CAMERA
            cameras += 1
        elif left == CAMERA or right == CAMERA:
            state[node] = COVERED
        else:
            state[node] = UNCOVERED
    if state[root] == UNCOVERED:
        cameras += 1
    return cameras



# ======================================================================
# task_08_vertical_traversal.py
# ======================================================================
"""Завдання 8. Вертикальний обхід дерева.

Сортування за (стовпець, рядок, значення), O(n log n) часу.
"""


def verticalTraversal(root: TreeNode | None) -> list[list[int]]:
    if root is None:
        return []
    cells = []
    queue = deque([(root, 0, 0)])  # node, row, col
    while queue:
        node, row, col = queue.popleft()
        cells.append((col, row, node.val))
        if node.left is not None:
            queue.append((node.left, row + 1, col - 1))
        if node.right is not None:
            queue.append((node.right, row + 1, col + 1))
    cells.sort()
    answer = []
    current_col = None
    for col, row, value in cells:
        if col != current_col:
            answer.append([])
            current_col = col
        answer[-1].append(value)
    return answer



# ======================================================================
# task_09_recover_preorder.py
# ======================================================================
"""Завдання 9. Відновити дерево з preorder та позначеної глибини.

Під час обходу тримаємо шлях батьків у стеку. O(n) часу/пам'яті.
"""


def recoverFromPreorder(traversal: str) -> TreeNode | None:
    if not traversal:
        return None
    stack = []
    i = 0
    while i < len(traversal):
        depth = 0
        while i < len(traversal) and traversal[i] == '-':
            depth += 1
            i += 1
        start = i
        while i < len(traversal) and traversal[i].isdigit():
            i += 1
        if start == i:
            raise ValueError('Очікувалося число після позначення глибини')
        node = TreeNode(int(traversal[start:i]))
        if depth > len(stack):
            raise ValueError('Некоректний перехід глибини')
        while len(stack) > depth:
            stack.pop()
        if stack:
            parent = stack[-1]
            if parent.left is None:
                parent.left = node
            elif parent.right is None:
                parent.right = node
            else:
                raise ValueError('Вузол не може мати понад двох дітей')
        elif depth != 0:
            raise ValueError('Корінь має глибину 0')
        stack.append(node)
    return stack[0] if stack else None
