"""Завдання 3. Квадрати елементів відсортованого масиву."""


def sorted_squares(nums: list[int]) -> list[int]:
    n = len(nums)
    answer = [0] * n
    left, right = 0, n - 1
    for pos in range(n - 1, -1, -1):
        if abs(nums[left]) > abs(nums[right]):
            answer[pos] = nums[left] * nums[left]
            left += 1
        else:
            answer[pos] = nums[right] * nums[right]
            right -= 1
    return answer


if __name__ == "__main__":
    print(sorted_squares([-4, -1, 0, 3, 10]))  # [0, 1, 9, 16, 100]
    print(sorted_squares([-7, -3, 2, 3, 11]))  # [4, 9, 9, 49, 121]
