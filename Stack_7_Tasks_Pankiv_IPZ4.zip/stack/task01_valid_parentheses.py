"""Завдання 1. Валідні дужки. O(n) часу, O(n) пам'яті."""


def is_valid(s: str) -> bool:
    pairs = {')': '(', ']': '[', '}': '{'}
    stack = []
    for ch in s:
        if ch in '([{':
            stack.append(ch)
        elif not stack or stack.pop() != pairs[ch]:
            return False
    return not stack


class Solution:
    def isValid(self, s: str) -> bool:
        return is_valid(s)
