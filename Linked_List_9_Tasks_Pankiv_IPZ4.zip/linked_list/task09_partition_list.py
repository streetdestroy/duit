"""№9. Стабільний поділ списку на значення < x та >= x."""
from common import ListNode


def partition_list(head: ListNode | None, x: int) -> ListNode | None:
    less_dummy = ListNode()
    greater_dummy = ListNode()
    less_tail = less_dummy
    greater_tail = greater_dummy
    current = head
    while current is not None:
        following = current.next
        current.next = None  # Від'єднуємо вузол від старого ланцюга.
        if current.val < x:
            less_tail.next = current
            less_tail = current
        else:
            greater_tail.next = current
            greater_tail = current
        current = following
    less_tail.next = greater_dummy.next
    return less_dummy.next
