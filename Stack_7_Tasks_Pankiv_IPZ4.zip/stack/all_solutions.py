"""Розв’язки усіх семи завдань Google Forms «Стек (Stack)».
Студент: Паньків Даніїл Васильович, ІПЗ-4.
Кожен алгоритм можна імпортувати окремо."""

from typing import Optional


# --- task01_valid_parentheses.py ---


def is_valid(s: str) -> bool:
    pairs = {')': '(', ']': '[', '}': '{'}
    stack = []
    for ch in s:
        if ch in '([{':
            stack.append(ch)
        elif not stack or stack.pop() != pairs[ch]:
            return False
    return not stack

# --- task02_inorder_traversal.py ---


class TreeNode:
    def __init__(self, val: int = 0, left: Optional['TreeNode'] = None,
                 right: Optional['TreeNode'] = None):
        self.val, self.left, self.right = val, left, right


def inorder_traversal(root: Optional[TreeNode]) -> list[int]:
    result = []
    stack = []
    node = root
    while node is not None or stack:
        while node is not None:
            stack.append(node)
            node = node.left
        node = stack.pop()
        result.append(node.val)
        node = node.right
    return result

# --- task03_min_stack.py ---


class MinStack:
    def __init__(self):
        # Кожен елемент: (значення, мінімум серед елементів до цієї позиції).
        self._data = []

    def push(self, val: int) -> None:
        current_min = val if not self._data else min(val, self._data[-1][1])
        self._data.append((val, current_min))

    def pop(self) -> None:
        self._data.pop()

    def top(self) -> int:
        return self._data[-1][0]

    def getMin(self) -> int:
        return self._data[-1][1]

# --- task04_queue_using_stacks.py ---


class MyQueue:
    def __init__(self):
        self._incoming = []
        self._outgoing = []

    def push(self, x: int) -> None:
        self._incoming.append(x)

    def _prepare_front(self) -> None:
        if not self._outgoing:
            while self._incoming:
                self._outgoing.append(self._incoming.pop())

    def pop(self) -> int:
        self._prepare_front()
        return self._outgoing.pop()

    def peek(self) -> int:
        self._prepare_front()
        return self._outgoing[-1]

    def empty(self) -> bool:
        return not self._incoming and not self._outgoing

# --- task05_decode_string.py ---


def decode_string(s: str) -> str:
    stack = []                  # (текст до групи, кількість повторів)
    current = ''
    count = 0
    for ch in s:
        if ch.isdigit():
            count = count * 10 + int(ch)
        elif ch == '[':
            stack.append((current, count))
            current = ''
            count = 0
        elif ch == ']':
            prefix, times = stack.pop()
            current = prefix + current * times
        else:
            current += ch
    return current

# --- task06_evaluate_rpn.py ---


def eval_rpn(tokens: list[str]) -> int:
    stack = []
    for token in tokens:
        if token in ('+', '-', '*', '/'):
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                value = a + b
            elif token == '-':
                value = a - b
            elif token == '*':
                value = a * b
            else:
                # На відміну від //, усікаємо результат до нуля і для від'ємних чисел.
                magnitude = abs(a) // abs(b)
                value = -magnitude if (a < 0) != (b < 0) else magnitude
            stack.append(value)
        else:
            stack.append(int(token))
    return stack[-1]

# --- task07_longest_valid_parentheses.py ---


def longest_valid_parentheses(s: str) -> int:
    stack = [-1]  # Індекс останньої некоректної ')' або межі рядка.
    best = 0
    for index, ch in enumerate(s):
        if ch == '(':
            stack.append(index)
        else:
            stack.pop()
            if stack:
                best = max(best, index - stack[-1])
            else:
                stack.append(index)
    return best


class Solution:
    """Універсальний клас з методами задач 1, 2, 5, 6 і 7."""

    def isValid(self, s: str) -> bool:
        return is_valid(s)

    def inorderTraversal(self, root: Optional[TreeNode]) -> list[int]:
        return inorder_traversal(root)

    def decodeString(self, s: str) -> str:
        return decode_string(s)

    def evalRPN(self, tokens: list[str]) -> int:
        return eval_rpn(tokens)

    def longestValidParentheses(self, s: str) -> int:
        return longest_valid_parentheses(s)
