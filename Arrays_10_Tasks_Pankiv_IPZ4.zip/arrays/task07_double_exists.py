"""Завдання 7. Перевірка існування N та 2*N у різних позиціях."""


def check_if_exist(arr: list[int]) -> bool:
    seen: set[int] = set()
    for number in arr:
        # Перевірка до додавання у seen виключає використання одного індексу двічі.
        if number * 2 in seen or (number % 2 == 0 and number // 2 in seen):
            return True
        seen.add(number)
    return False


if __name__ == "__main__":
    print(check_if_exist([10, 2, 5, 3]))  # True
    print(check_if_exist([3, 1, 7, 11]))  # False
