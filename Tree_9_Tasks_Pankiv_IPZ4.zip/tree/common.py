"""Допоміжні засоби для тестів і демонстрації бінарних дерев."""
from collections import deque
from typing import Optional


class TreeNode:
    """Вузол бінарного дерева у форматі LeetCode."""

    def __init__(self, val: int = 0,
                 left: Optional['TreeNode'] = None,
                 right: Optional['TreeNode'] = None):
        self.val = val
        self.left = left
        self.right = right


def build_tree(values: list) -> Optional[TreeNode]:
    """Створити дерево з level-order запису: [1, None, 2, 3]."""
    if not values or values[0] is None:
        return None
    root = TreeNode(values[0])
    queue = deque([root])
    index = 1
    while queue and index < len(values):
        parent = queue.popleft()
        if index < len(values):
            value = values[index]
            index += 1
            if value is not None:
                parent.left = TreeNode(value)
                queue.append(parent.left)
        if index < len(values):
            value = values[index]
            index += 1
            if value is not None:
                parent.right = TreeNode(value)
                queue.append(parent.right)
    return root


def tree_to_list(root: Optional[TreeNode]) -> list:
    """Перетворити дерево в level-order список без кінцевих None."""
    if root is None:
        return []
    values = []
    queue = deque([root])
    while queue:
        node = queue.popleft()
        if node is None:
            values.append(None)
        else:
            values.append(node.val)
            queue.append(node.left)
            queue.append(node.right)
    while values and values[-1] is None:
        values.pop()
    return values
