"""Завдання 7. Мінімальна кількість камер.

Жадібний алгоритм, ітеративний postorder, O(n) часу та пам'яті.
"""
from common import TreeNode


def minCameraCover(root: TreeNode | None) -> int:
    if root is None:
        return 0
    UNCOVERED, COVERED, CAMERA = 0, 1, 2
    state = {None: COVERED}
    cameras = 0
    stack = [(root, False)]
    while stack:
        node, visited = stack.pop()
        if node is None:
            continue
        if not visited:
            stack.append((node, True))
            stack.append((node.right, False))
            stack.append((node.left, False))
            continue
        left = state[node.left]
        right = state[node.right]
        if left == UNCOVERED or right == UNCOVERED:
            state[node] = CAMERA
            cameras += 1
        elif left == CAMERA or right == CAMERA:
            state[node] = COVERED
        else:
            state[node] = UNCOVERED
    if state[root] == UNCOVERED:
        cameras += 1
    return cameras
