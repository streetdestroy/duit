"""Завдання 2. Симетричний обхід дерева (left-root-right). O(n) часу."""
from typing import Optional


class TreeNode:
    def __init__(self, val: int = 0, left: Optional['TreeNode'] = None,
                 right: Optional['TreeNode'] = None):
        self.val, self.left, self.right = val, left, right


def inorder_traversal(root: Optional[TreeNode]) -> list[int]:
    result = []
    stack = []
    node = root
    while node is not None or stack:
        while node is not None:
            stack.append(node)
            node = node.left
        node = stack.pop()
        result.append(node.val)
        node = node.right
    return result


class Solution:
    def inorderTraversal(self, root: Optional[TreeNode]) -> list[int]:
        return inorder_traversal(root)
