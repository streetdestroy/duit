"""Автотести ПР «Дерева». Запуск: python -m unittest -v test_solutions.py"""
import random
import unittest
from collections import deque

from common import TreeNode, build_tree, tree_to_list
from task_01_same_tree import isSameTree
from task_02_symmetric_tree import isSymmetric
from task_03_invert_tree import invertTree
from task_04_kth_smallest import kthSmallest
from task_05_codec import Codec
from task_06_max_path_sum import maxPathSum
from task_07_cameras import minCameraCover
from task_08_vertical_traversal import verticalTraversal
from task_09_recover_preorder import recoverFromPreorder


def make_random_tree(rng, size, low=-10, high=10):
    if size == 0:
        return None
    root = TreeNode(rng.randint(low, high))
    available = [root]
    for _ in range(size - 1):
        node = TreeNode(rng.randint(low, high))
        index = rng.randrange(len(available))
        parent = available[index]
        # Якщо один нащадок, він повинен бути лівим (для задачі 9).
        if parent.left is None:
            parent.left = node
        else:
            parent.right = node
            available[index] = available[-1]
            available.pop()
        available.append(node)
    return root


def preorder_depth(root):
    out = []
    stack = [(root, 0)]
    while stack:
        node, depth = stack.pop()
        if node is None:
            continue
        out.append('-' * depth + str(node.val))
        stack.append((node.right, depth + 1))
        stack.append((node.left, depth + 1))
    return ''.join(out)


def all_nodes(root):
    if root is None:
        return []
    result, stack = [], [root]
    while stack:
        node = stack.pop()
        result.append(node)
        if node.left is not None:
            stack.append(node.left)
        if node.right is not None:
            stack.append(node.right)
    return result


def brute_max_path(root):
    nodes = all_nodes(root)
    adj = {node: [] for node in nodes}
    for node in nodes:
        for child in [node.left, node.right]:
            if child is not None:
                adj[node].append(child)
                adj[child].append(node)
    best = -10**10
    for start in nodes:
        stack = [(start, None, 0)]
        while stack:
            node, parent, total = stack.pop()
            total += node.val
            best = max(best, total)
            for neighbor in adj[node]:
                if neighbor is not parent:
                    stack.append((neighbor, node, total))
    return best


def brute_cameras(root):
    nodes = all_nodes(root)
    n = len(nodes)
    if n == 0:
        return 0
    positions = {node: index for index, node in enumerate(nodes)}
    parent = {root: None}
    for node in nodes:
        if node.left is not None:
            parent[node.left] = node
        if node.right is not None:
            parent[node.right] = node
    covers = []
    for node in nodes:
        covered = {node, parent[node], node.left, node.right}
        mask = 0
        for v in covered:
            if v is not None:
                mask |= 1 << positions[v]
        covers.append(mask)
    best = n
    for mask in range(1 << n):
        count = mask.bit_count()
        if count >= best:
            continue
        observed = 0
        for i in range(n):
            if mask & (1 << i):
                observed |= covers[i]
        if observed == (1 << n) - 1:
            best = count
    return best


def bst_insert(root, value):
    if root is None:
        return TreeNode(value)
    node = root
    while True:
        if value < node.val:
            if node.left is None:
                node.left = TreeNode(value)
                return root
            node = node.left
        else:
            if node.right is None:
                node.right = TreeNode(value)
                return root
            node = node.right


class TreeTasksTests(unittest.TestCase):
    def test_01_examples(self):
        self.assertTrue(isSameTree(build_tree([1, 2, 3]), build_tree([1, 2, 3])))
        self.assertFalse(isSameTree(build_tree([1, 2]), build_tree([1, None, 2])))
        self.assertFalse(isSameTree(build_tree([1, 2, 1]), build_tree([1, 1, 2])))
        self.assertTrue(isSameTree(None, None))
        self.assertFalse(isSameTree(TreeNode(0), None))

    def test_02_examples(self):
        self.assertTrue(isSymmetric(build_tree([1, 2, 2, 3, 4, 4, 3])))
        self.assertFalse(isSymmetric(build_tree([1, 2, 2, None, 3, None, 3])))
        self.assertTrue(isSymmetric(None))
        self.assertTrue(isSymmetric(TreeNode(1)))

    def test_03_examples(self):
        for source, expected in [
            ([4, 2, 7, 1, 3, 6, 9], [4, 7, 2, 9, 6, 3, 1]),
            ([2, 1, 3], [2, 3, 1]),
            ([], []),
        ]:
            self.assertEqual(tree_to_list(invertTree(build_tree(source))), expected)

    def test_04_examples(self):
        self.assertEqual(kthSmallest(build_tree([3, 1, 4, None, 2]), 1), 1)
        self.assertEqual(kthSmallest(build_tree([5, 3, 6, 2, 4, None, None, 1]), 3), 3)

    def test_05_examples(self):
        codec = Codec()
        for values in [[1, 2, 3, None, None, 4, 5], [], [1], [1, None, 2, -5]]:
            root = build_tree(values)
            serialized = codec.serialize(root)
            restored = codec.deserialize(serialized)
            self.assertTrue(isSameTree(root, restored))
            self.assertEqual(tree_to_list(restored), values)
        self.assertEqual(codec.serialize(None), '#')
        self.assertIsNone(codec.deserialize('#'))

    def test_06_examples(self):
        self.assertEqual(maxPathSum(build_tree([1, 2, 3])), 6)
        self.assertEqual(maxPathSum(build_tree([-10, 9, 20, None, None, 15, 7])), 42)
        self.assertEqual(maxPathSum(TreeNode(-3)), -3)
        self.assertEqual(maxPathSum(build_tree([-2, -1])), -1)

    def test_07_examples(self):
        self.assertEqual(minCameraCover(build_tree([0, 0, None, 0, 0])), 1)
        self.assertEqual(minCameraCover(build_tree([0, 0, None, 0, None, 0, None, None, 0])), 2)
        self.assertEqual(minCameraCover(build_tree([0])), 1)
        self.assertEqual(minCameraCover(None), 0)

    def test_08_examples(self):
        self.assertEqual(verticalTraversal(build_tree([3, 9, 20, None, None, 15, 7])),
                         [[9], [3, 15], [20], [7]])
        self.assertEqual(verticalTraversal(build_tree([1, 2, 3, 4, 5, 6, 7])),
                         [[4], [2], [1, 5, 6], [3], [7]])
        self.assertEqual(verticalTraversal(build_tree([1, 2, 3, 4, 6, 5, 7])),
                         [[4], [2], [1, 5, 6], [3], [7]])
        self.assertEqual(verticalTraversal(None), [])

    def test_09_examples(self):
        self.assertEqual(tree_to_list(recoverFromPreorder('1-2--3--4-5--6--7')),
                         [1, 2, 5, 3, 4, 6, 7])
        self.assertEqual(tree_to_list(recoverFromPreorder('1-2--3---4-5--6---7')),
                         [1, 2, 5, 3, None, 6, None, 4, None, 7])
        self.assertEqual(tree_to_list(recoverFromPreorder('1-401--349---90--88')),
                         [1, 401, None, 349, 88, 90])

    def test_randomized_codec_preorder_inversion_and_sameness(self):
        rng = random.Random(17)
        codec = Codec()
        for _ in range(300):
            root = make_random_tree(rng, rng.randrange(0, 100), 0, 1000)
            rebuilt = codec.deserialize(codec.serialize(root))
            self.assertTrue(isSameTree(root, rebuilt))
            self.assertEqual(tree_to_list(root), tree_to_list(rebuilt))
            if root is not None:
                preorder = preorder_depth(root)
                recovered = recoverFromPreorder(preorder)
                self.assertTrue(isSameTree(root, recovered))
            inverted = invertTree(root)
            self.assertTrue(isSameTree(rebuilt, invertTree(inverted)))

    def test_randomized_kth(self):
        rng = random.Random(17)
        for _ in range(30):
            vals = rng.sample(range(0, 10000), rng.randrange(1, 200))
            root = None
            for v in vals:
                root = bst_insert(root, v)
            for k in range(1, len(vals) + 1):
                self.assertEqual(kthSmallest(root, k), sorted(vals)[k-1])

    def test_randomized_max_path_sum(self):
        rng = random.Random(9)
        for _ in range(200):
            root = make_random_tree(rng, rng.randrange(1, 13), -12, 15)
            self.assertEqual(maxPathSum(root), brute_max_path(root))

    def test_randomized_cameras(self):
        rng = random.Random(7)
        for _ in range(100):
            root = make_random_tree(rng, rng.randrange(1, 10), 0, 0)
            self.assertEqual(minCameraCover(root), brute_cameras(root))

    def test_symmetry_random_mirror(self):
        rng = random.Random(17)
        for _ in range(50):
            subtree = make_random_tree(rng, rng.randrange(0, 30))
            # Створюємо дзеркало, не змінюючи оригіналу.
            mirrored = Codec().deserialize(Codec().serialize(subtree))
            invertTree(mirrored)
            root = TreeNode(99, subtree, mirrored)
            self.assertTrue(isSymmetric(root))

    def test_extreme_depth_without_recursion(self):
        # 30 тис. вузлів: задача №6; 10 тис. — задача №5, 1000 — №7 та №9.
        long_root = TreeNode(-1)
        cursor = long_root
        for _ in range(29999):
            cursor.left = TreeNode(-1)
            cursor = cursor.left
        self.assertEqual(maxPathSum(long_root), -1)
        self.assertEqual(kthSmallest(make_right_bst_chain(10000), 10000), 9999)
        many = make_right_bst_chain(10000)
        restored = Codec().deserialize(Codec().serialize(many))
        self.assertTrue(isSameTree(many, restored))
        chain = TreeNode(0)
        p = chain
        for _ in range(999):
            p.left = TreeNode(0)
            p = p.left
        self.assertEqual(minCameraCover(chain), 334)
        self.assertTrue(isSameTree(chain, recoverFromPreorder(preorder_depth(chain))))

    def test_all_solutions_standalone(self):
        import all_solutions as a
        self.assertTrue(a.isSameTree(a.build_tree([1, 2]), a.build_tree([1, 2])))
        self.assertTrue(a.isSymmetric(a.build_tree([1, 2, 2])))
        self.assertEqual(a.tree_to_list(a.invertTree(a.build_tree([2, 1, 3]))), [2, 3, 1])
        self.assertEqual(a.kthSmallest(a.build_tree([2, 1, 3]), 2), 2)
        tree = a.build_tree([1, 2, 3])
        self.assertTrue(a.isSameTree(tree, a.Codec().deserialize(a.Codec().serialize(tree))))
        self.assertEqual(a.maxPathSum(tree), 6)
        self.assertEqual(a.minCameraCover(a.build_tree([0, 0, 0])), 1)
        self.assertEqual(a.verticalTraversal(a.build_tree([1, 2, 3])), [[2], [1], [3]])
        self.assertEqual(a.tree_to_list(a.recoverFromPreorder('1-2-3')), [1, 2, 3])


def make_right_bst_chain(size):
    root = TreeNode(0)
    node = root
    for i in range(1, size):
        node.right = TreeNode(i)
        node = node.right
    return root


if __name__ == '__main__':
    unittest.main(verbosity=2)
