"""Завдання 9. Відновити дерево з preorder та позначеної глибини.

Під час обходу тримаємо шлях батьків у стеку. O(n) часу/пам'яті.
"""
from common import TreeNode


def recoverFromPreorder(traversal: str) -> TreeNode | None:
    if not traversal:
        return None
    stack = []
    i = 0
    while i < len(traversal):
        depth = 0
        while i < len(traversal) and traversal[i] == '-':
            depth += 1
            i += 1
        start = i
        while i < len(traversal) and traversal[i].isdigit():
            i += 1
        if start == i:
            raise ValueError('Очікувалося число після позначення глибини')
        node = TreeNode(int(traversal[start:i]))
        if depth > len(stack):
            raise ValueError('Некоректний перехід глибини')
        while len(stack) > depth:
            stack.pop()
        if stack:
            parent = stack[-1]
            if parent.left is None:
                parent.left = node
            elif parent.right is None:
                parent.right = node
            else:
                raise ValueError('Вузол не може мати понад двох дітей')
        elif depth != 0:
            raise ValueError('Корінь має глибину 0')
        stack.append(node)
    return stack[0] if stack else None
