"""Завдання 8. Вертикальний обхід дерева.

Сортування за (стовпець, рядок, значення), O(n log n) часу.
"""
from collections import deque
from common import TreeNode


def verticalTraversal(root: TreeNode | None) -> list[list[int]]:
    if root is None:
        return []
    cells = []
    queue = deque([(root, 0, 0)])  # node, row, col
    while queue:
        node, row, col = queue.popleft()
        cells.append((col, row, node.val))
        if node.left is not None:
            queue.append((node.left, row + 1, col - 1))
        if node.right is not None:
            queue.append((node.right, row + 1, col + 1))
    cells.sort()
    answer = []
    current_col = None
    for col, row, value in cells:
        if col != current_col:
            answer.append([])
            current_col = col
        answer[-1].append(value)
    return answer
