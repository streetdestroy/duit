"""№6. Подвоїти число у вигляді списку цифр без перетворення у int."""
from common import ListNode


def _reverse(head: ListNode | None) -> ListNode | None:
    previous = None
    current = head
    while current is not None:
        following = current.next
        current.next = previous
        previous = current
        current = following
    return previous


def double_it(head: ListNode) -> ListNode:
    # Рух із молодших розрядів дозволяє переносити десятки.
    current = _reverse(head)
    reversed_head = current
    carry = 0
    tail = None
    while current is not None:
        value = current.val * 2 + carry
        current.val = value % 10
        carry = value // 10
        tail = current
        current = current.next
    if carry:
        tail.next = ListNode(carry)
    return _reverse(reversed_head)
