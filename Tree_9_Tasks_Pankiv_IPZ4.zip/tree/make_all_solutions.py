"""Допоміжний скрипт для підтримки синхронності загального файлу."""
from pathlib import Path
root = Path(__file__).resolve().parent
common = (root / 'common.py').read_text(encoding='utf-8')
parts = ["# Усі 9 завдань 'Дерева (Tree)' — Паньків Даніїл Васильович, ІПЗ-4\n", common]
for i in range(1, 10):
    fn = next(root.glob(f'task_{i:02d}_*.py'))
    source = fn.read_text(encoding='utf-8')
    source = source.replace('from common import TreeNode\n', '')
    source = source.replace('from collections import deque\n', '')
    parts.append('\n\n# ' + '=' * 70 + '\n# ' + fn.name + '\n# ' + '=' * 70 + '\n' + source)
(root / 'all_solutions.py').write_text('\n'.join(parts), encoding='utf-8')
