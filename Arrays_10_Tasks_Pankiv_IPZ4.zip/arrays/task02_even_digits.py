"""Завдання 2. Кількість чисел із парною кількістю цифр."""


def find_numbers(nums: list[int]) -> int:
    result = 0
    for value in nums:
        count = 0
        while value > 0:
            value //= 10
            count += 1
        if count % 2 == 0:
            result += 1
    return result


if __name__ == "__main__":
    print(find_numbers([12, 345, 2, 6, 7896]))  # 2
    print(find_numbers([555, 901, 482, 1771]))  # 1
