"""Завдання 4. Дублювання нулів у масиві фіксованої довжини."""


def duplicate_zeros(arr: list[int]) -> None:
    """Змінює arr на місці, зберігаючи початкову довжину."""
    n = len(arr)
    zeros = 0
    for value in arr:
        if value == 0:
            zeros += 1

    write = n + zeros - 1
    for read in range(n - 1, -1, -1):
        if write < n:
            arr[write] = arr[read]
        if arr[read] == 0:
            write -= 1
            if write < n:
                arr[write] = 0
        write -= 1


if __name__ == "__main__":
    example = [1, 0, 2, 3, 0, 4, 5, 0]
    duplicate_zeros(example)
    print(example)  # [1, 0, 0, 2, 3, 0, 0, 4]
    example = [1, 2, 3]
    duplicate_zeros(example)
    print(example)  # [1, 2, 3]
