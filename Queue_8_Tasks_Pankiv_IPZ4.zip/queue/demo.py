"""Демонстрація прикладів з Google-форми."""
from all_solutions import (firstUniqChar, MyStack, RecentCounter, MyCircularDeque,
                           MyCircularQueue, movesToStamp, maxSlidingWindow,
                           constrainedSubsetSum)

print('1:', firstUniqChar('leopard'), firstUniqChar('loveleopard'), firstUniqChar('aabb'))
s = MyStack(); s.push(1); s.push(2)
print('2:', s.top(), s.pop(), s.empty())
r = RecentCounter()
print('3:', [r.ping(t) for t in [1, 100, 3001, 3002]])
d = MyCircularDeque(3)
print('4:', [d.insertLast(1), d.insertLast(2), d.insertFront(3), d.insertFront(4),
             d.getRear(), d.isFull(), d.deleteLast(), d.insertFront(4), d.getFront()])
q = MyCircularQueue(3)
print('5:', [q.enQueue(1), q.enQueue(2), q.enQueue(3), q.enQueue(4),
             q.Rear(), q.isFull(), q.deQueue(), q.enQueue(4), q.Rear()])
print('6:', movesToStamp('abc', 'ababc'), movesToStamp('abca', 'aabcaca'))
print('7:', maxSlidingWindow([1, 3, -1, -3, 5, 3, 6, 7], 3))
print('8:', constrainedSubsetSum([10, 2, -10, 5, 20], 2))
