"""Запуск прикладів усіх дев'яти завдань з Google Forms."""
from common import ListNode, from_list, to_list
from task01_merge_two_sorted_lists import merge_two_lists
from task02_remove_duplicates import delete_duplicates
from task03_linked_list_cycle import has_cycle
from task04_reorder_list import reorder_list
from task05_delete_node import delete_node
from task06_double_number import double_it
from task07_merge_k_sorted_lists import merge_k_lists
from task08_reverse_nodes_k_group import reverse_k_group
from task09_partition_list import partition_list


def run():
    assert to_list(merge_two_lists(from_list([1, 2, 4]), from_list([1, 3, 4]))) == [1, 1, 2, 3, 4, 4]
    assert to_list(merge_two_lists(None, None)) == []
    assert to_list(merge_two_lists(None, from_list([0]))) == [0]
    print('1. Злиття двох списків: [1, 1, 2, 3, 4, 4]')

    assert to_list(delete_duplicates(from_list([1, 1, 2]))) == [1, 2]
    assert to_list(delete_duplicates(from_list([1, 1, 2, 3, 3]))) == [1, 2, 3]
    print('2. Видалення дублікатів: [1, 2, 3]')

    head = from_list([3, 2, 0, -4])
    head.next.next.next.next = head.next
    assert has_cycle(head) is True
    assert has_cycle(from_list([1])) is False
    print('3. Виявлення циклу: True / False')

    head = from_list([1, 2, 3, 4, 5])
    reorder_list(head)
    assert to_list(head) == [1, 5, 2, 4, 3]
    print('4. Перевпорядкування: [1, 5, 2, 4, 3]')

    head = from_list([4, 5, 1, 9])
    delete_node(head.next)
    assert to_list(head) == [4, 1, 9]
    print('5. Видалення вузла: [4, 1, 9]')

    assert to_list(double_it(from_list([1, 8, 9]))) == [3, 7, 8]
    assert to_list(double_it(from_list([9, 9, 9]))) == [1, 9, 9, 8]
    print('6. Подвоєння: [3, 7, 8] / [1, 9, 9, 8]')

    heads = [from_list(v) for v in [[1, 4, 5], [1, 3, 4], [2, 6]]]
    assert to_list(merge_k_lists(heads)) == [1, 1, 2, 3, 4, 4, 5, 6]
    print('7. Злиття k списків: [1, 1, 2, 3, 4, 4, 5, 6]')

    assert to_list(reverse_k_group(from_list([1, 2, 3, 4, 5]), 2)) == [2, 1, 4, 3, 5]
    assert to_list(reverse_k_group(from_list([1, 2, 3, 4, 5]), 3)) == [3, 2, 1, 4, 5]
    print('8. Реверс k-груп: [2, 1, 4, 3, 5] / [3, 2, 1, 4, 5]')

    assert to_list(partition_list(from_list([1, 4, 3, 2, 5, 2]), 3)) == [1, 2, 2, 4, 3, 5]
    assert to_list(partition_list(from_list([2, 1]), 2)) == [1, 2]
    print('9. Стабільний поділ: [1, 2, 2, 4, 3, 5]')
    print('Усі приклади з умови пройдено.')


if __name__ == '__main__':
    run()
