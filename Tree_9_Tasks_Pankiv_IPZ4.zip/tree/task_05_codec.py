"""Завдання 5. Серіалізація та десеріалізація дерева.

Власний формат: preorder (вузол, ліво, право), # = відсутній вузол.
Без глибокої рекурсії; O(n) часу й пам'яті.
"""
from common import TreeNode


class Codec:
    def serialize(self, root: TreeNode | None) -> str:
        tokens = []
        stack = [root]
        while stack:
            node = stack.pop()
            if node is None:
                tokens.append('#')
            else:
                tokens.append(str(node.val))
                stack.append(node.right)
                stack.append(node.left)
        return ','.join(tokens)

    def deserialize(self, data: str) -> TreeNode | None:
        if not data or data == '#':
            return None
        tokens = iter(data.split(','))
        first = next(tokens)
        root = TreeNode(int(first))
        # У кадрі: (вузол, слот 0 = лівий; слот 1 = правий).
        stack = [(root, 0)]
        for token in tokens:
            if not stack:
                raise ValueError('Зайві токени в серіалізованому дереві')
            node, side = stack.pop()
            child = None if token == '#' else TreeNode(int(token))
            if side == 0:
                node.left = child
                stack.append((node, 1))
            else:
                node.right = child
            if child is not None:
                stack.append((child, 0))
        if stack:
            raise ValueError('Серіалізоване дерево обірване')
        return root
