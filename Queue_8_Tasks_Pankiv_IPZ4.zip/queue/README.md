# Черга (Queue) — 8 завдань Google Forms

**Студент:** Паньків Даніїл Васильович  
**Група:** ІПЗ-4  
**Мова:** Python 3.10+ (лише стандартна бібліотека)

> У формі є **8 завдань**, але номер 3 надрукований двічі. Нижче — порядкова нумерація без пропусків.  
> Умови для `insertFront` і `insertLast` у формі пропускають параметр `value` у переліку методів. Правильна сигнатура — `insertFront(value)` / `insertLast(value)` за прикладом викликів.

| Порядок | Номер у формі | Зміст | Файл | Складність |
|---|---|---|---|---|
| 1 | 1 | Перший унікальний символ | `task01_first_unique.py` | O(n) часу, O(1) дод. пам'яті |
| 2 | 2 | Стек з двох черг | `task02_stack_using_queues.py` | push O(n), pop/top O(1) |
| 3 | 3 | RecentCounter: запити за 3000 мс | `task03_recent_counter.py` | амортизовано O(1)/ping |
| 4 | 3 (повтор) | MyCircularDeque | `task04_circular_deque.py` | O(1) на операцію |
| 5 | 4 | MyCircularQueue | `task05_circular_queue.py` | O(1) на операцію |
| 6 | 5 | Штампування послідовності | `task06_stamping_sequence.py` | O(m·n) часу й пам'яті |
| 7 | 6 | Максимум ковзного вікна | `task07_sliding_window_max.py` | O(n) часу, O(k) пам'яті |
| 8 | 7 | Обмежена сума підпослідовності | `task08_constrained_subsequence_sum.py` | O(n) часу й пам'яті |

**Один самодостатній файл з усіма рішеннями:** `all_solutions.py`.
Для подання на LeetCode у деяких завданнях окремі файли мають обгортку `class Solution` з потрібним методом.

## Запуск

```bash
python demo.py
python -m unittest -v test_solutions.py
```

Описані функції/класи:
- `firstUniqChar(s)`
- `MyStack` (`push`, `pop`, `top`, `empty`)
- `RecentCounter` (`ping`)
- `MyCircularDeque` (`insertFront`, `insertLast`, `deleteFront`, `deleteLast`, `getFront`, `getRear`, `isEmpty`, `isFull`)
- `MyCircularQueue` (`enQueue`, `deQueue`, `Front`, `Rear`, `isEmpty`, `isFull`)
- `movesToStamp(stamp, target)` — допускається будь-яка валідна послідовність штампувань, не лише приклад із форми
- `maxSlidingWindow(nums, k)`
- `constrainedSubsetSum(nums, k)`

## Як здати

1. Завантажте папку **`queue`** в публічний GitHub-репозиторій.
2. Переконайтесь, що файли видно у GitHub.
3. Вставте у Google-форму посилання на папку:

`https://github.com/streetdestroy/duit/tree/main/queue`

> Важливо: це посилання працюватиме на код **лише після** фактичного завантаження папки в GitHub.
