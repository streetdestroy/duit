"""Завдання 6. Зворотна польська нотація (RPN). Ділення до нуля."""


def eval_rpn(tokens: list[str]) -> int:
    stack = []
    for token in tokens:
        if token in ('+', '-', '*', '/'):
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                value = a + b
            elif token == '-':
                value = a - b
            elif token == '*':
                value = a * b
            else:
                # На відміну від //, усікаємо результат до нуля і для від'ємних чисел.
                magnitude = abs(a) // abs(b)
                value = -magnitude if (a < 0) != (b < 0) else magnitude
            stack.append(value)
        else:
            stack.append(int(token))
    return stack[-1]


class Solution:
    def evalRPN(self, tokens: list[str]) -> int:
        return eval_rpn(tokens)
