"""Завдання 10. Парні числа перед непарними."""


def sort_array_by_parity(nums: list[int]) -> list[int]:
    left, right = 0, len(nums) - 1
    while left < right:
        if nums[left] % 2 == 0:
            left += 1
        elif nums[right] % 2 == 1:
            right -= 1
        else:
            nums[left], nums[right] = nums[right], nums[left]
            left += 1
            right -= 1
    return nums


if __name__ == "__main__":
    print(sort_array_by_parity([3, 1, 2, 4]))  # будь-яка допустима перестановка
    print(sort_array_by_parity([0]))  # [0]
