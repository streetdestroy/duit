"""Завдання 7 (№6 у формі): максимум кожного ковзного вікна, O(n)."""
from collections import deque


def maxSlidingWindow(nums: list[int], k: int) -> list[int]:
    candidates = deque()  # індекси; значення у спадному порядку
    result = []
    for i, value in enumerate(nums):
        while candidates and candidates[0] <= i - k:
            candidates.popleft()
        while candidates and nums[candidates[-1]] <= value:
            candidates.pop()
        candidates.append(i)
        if i + 1 >= k:
            result.append(nums[candidates[0]])
    return result


class Solution:
    def maxSlidingWindow(self, nums: list[int], k: int) -> list[int]:
        return maxSlidingWindow(nums, k)
